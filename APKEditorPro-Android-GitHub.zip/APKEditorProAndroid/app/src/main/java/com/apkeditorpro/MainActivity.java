package com.apkeditorpro;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.util.TypedValue;

public class MainActivity extends Activity {
    private TextView selectedFile;
    private static final int PICK_APK = 41;
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); getWindow().setStatusBarColor(Color.rgb(16,16,16)); getWindow().setNavigationBarColor(Color.rgb(16,16,16));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(24),dp(22),dp(22)); root.setBackgroundColor(Color.rgb(16,16,16));
        TextView title = text("APK EDITOR PRO", 27, Color.WHITE, true); root.addView(title);
        TextView subtitle = text("EDITOR DE APLICATIVOS ANDROID", 12, 0xFFB7FF00, true); LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(6); root.addView(subtitle,sp);
        TextView status = text("PROJETO ANDROID INICIAL", 12, 0xFF101010, true); status.setPadding(dp(12),dp(8),dp(12),dp(8)); status.setBackground(bg(0xFFB7FF00,18)); LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-2,-2); stp.topMargin=dp(26); root.addView(status,stp);
        TextView intro=text("Selecione um APK para iniciar. Esta versão confirma a estrutura Android e o seletor de arquivos.",16,Color.WHITE,false); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2); ip.topMargin=dp(18); root.addView(intro,ip);
        Button choose=new Button(this); choose.setText("SELECIONAR ARQUIVO APK"); choose.setTextColor(0xFF101010); choose.setAllCaps(false); choose.setBackground(bg(0xFFB7FF00,14)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(54)); cp.topMargin=dp(20); root.addView(choose,cp);
        selectedFile=text("Nenhum arquivo selecionado",13,0xFFCCCCCC,false); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2); fp.topMargin=dp(14); root.addView(selectedFile,fp);
        TextView features=text("FUNÇÕES DO PROJETO ORIGINAL\n\n• Decompilar e analisar APK\n• Editar servidores e textos\n• Substituir imagens, fontes e cores\n• Alterar nome, pacote e versão\n• Recompilar, alinhar e assinar",15,Color.WHITE,false); features.setPadding(dp(16),dp(16),dp(16),dp(16)); features.setBackground(bg(0xFF242424,14)); LinearLayout.LayoutParams fep=new LinearLayout.LayoutParams(-1,-2); fep.topMargin=dp(24); root.addView(features,fep);
        TextView note=text("IMPORTANTE: as funções acima existem no código original Python/Termux. Elas ainda precisam ser migradas para bibliotecas compatíveis com Android; esta compilação inicial não decompila nem recompila APKs.",12,0xFFFFD166,false); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2); np.topMargin=dp(18); root.addView(note,np);
        root.setGravity(Gravity.TOP); setContentView(root);
        choose.setOnClickListener(v -> { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/vnd.android.package-archive"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_APK); });
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_APK && resultCode==RESULT_OK && data!=null) { Uri uri=data.getData(); if(uri!=null) { String name=uri.getLastPathSegment(); selectedFile.setText("Arquivo selecionado: " + (name==null ? uri.toString() : name) + "\nPróxima etapa: integrar o motor de edição Android."); } } }
}
