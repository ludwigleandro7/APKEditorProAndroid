# APK Editor Pro Android — estrutura inicial

Este repositório contém um projeto Android compilável pelo GitHub Actions e uma cópia integral do projeto original Python/Termux em `original-source/`.

## Estado real
- A estrutura Android e o seletor de arquivos APK estão implementados.
- O código original foi preservado em `original-source/`.
- **A edição real de APK ainda NÃO foi migrada.** O backend original usa Flask, subprocessos e ferramentas de desktop/Termux (`apktool`, `aapt2`, `zipalign`, `apksigner`). Eles não funcionam automaticamente dentro de um app Android. O APK gerado neste estágio é uma base de interface, não um editor funcional completo.

## Gerar APK pelo celular usando GitHub
1. Abra seu repositório `APKEditorProAndroid` no navegador Android.
2. Extraia este ZIP e envie o conteúdo para a raiz do repositório. A raiz precisa mostrar `app/`, `build.gradle`, `settings.gradle`, `gradle.properties`, `.github/` e `original-source/` — não deixe somente o ZIP.
3. Abra **Actions** → **Build APK Android** → **Run workflow**.
4. Espere o check verde.
5. Abra a execução concluída, vá até **Artifacts** e baixe `APKEditorPro-debug`. Extraia o artefato para obter `app-debug.apk`.

## Próxima fase para o editor completo
É necessário portar o motor de edição para bibliotecas compatíveis com Android e integrar decompilação, edição de recursos, recompilação, alinhamento e assinatura. Isso exige implementação e testes separados; não é garantido apenas por configurar o workflow.
