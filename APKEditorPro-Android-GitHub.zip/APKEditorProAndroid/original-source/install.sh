#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  APK Editor Pro - instalador para Termux  (v2, auto-reparavel)
#  Instala TUDO: Java, apktool, apksigner, zipalign, aapt/aapt2,
#  Python, Flask e Pillow. Se um pacote nao existir no repositorio,
#  baixa a versao portatil (JAR) automaticamente.
# ============================================================
set -u
G="\033[1;32m"; Y="\033[1;33m"; R="\033[1;31m"; C="\033[1;36m"; N="\033[0m"

echo -e "${G}"
echo "  █████  ██████  ██   ██    ███████ ██████  ██ ████████  ██████  ██████"
echo "  ██  ██ ██   ██ ██  ██     ██      ██   ██ ██    ██    ██    ██ ██   ██"
echo "  ███████ ██████  █████      █████   ██   ██ ██    ██    ██    ██ ██████"
echo "  ██   ██ ██      ██  ██     ██      ██   ██ ██    ██    ██    ██ ██   ██"
echo "  ██   ██ ██      ██   ██    ███████ ██████  ██    ██     ██████  ██   ██"
echo -e "                          P R O${N}"
echo

TOOLS="$HOME/.apkeditor/tools"
mkdir -p "$TOOLS"
APKTOOL_URL="https://github.com/iBotPeaches/Apktool/releases/download/v2.11.1/apktool_2.11.1.jar"
UBER_URL="https://github.com/patrickfav/uber-apk-signer/releases/download/v1.3.0/uber-apk-signer-1.3.0.jar"

tem() { command -v "$1" >/dev/null 2>&1; }

# ---------------------------------------------------------------- 1. repos
echo -e "${C}[1/5] Repositorios${N}"
pkg update -y >/dev/null 2>&1 || true
echo -e "  ${Y}→${N} habilitando repositorio x11 (onde ficam apktool/apksigner)..."
pkg install -y x11-repo >/dev/null 2>&1 || true
pkg update -y >/dev/null 2>&1 || true

# ---------------------------------------------------------------- 2. pacotes
echo -e "${C}[2/5] Pacotes do Termux${N}"
instalar_pkg() {
  local p="$1" bin="$2"
  if [ -n "$bin" ] && tem "$bin"; then
    echo -e "  ${G}✓${N} $p (ja instalado)"; return 0
  fi
  printf "  ${Y}→${N} instalando %-16s " "$p"
  if pkg install -y "$p" >/dev/null 2>&1; then
    if [ -z "$bin" ] || tem "$bin"; then echo -e "${G}ok${N}"; return 0; fi
  fi
  echo -e "${R}indisponivel${N}"; return 1
}

instalar_pkg python        python3
instalar_pkg openjdk-17    java
instalar_pkg zipalign      zipalign
instalar_pkg aapt          aapt
instalar_pkg aapt2         aapt2
instalar_pkg apksigner     apksigner
instalar_pkg apktool       apktool
instalar_pkg python-pillow ""

# ---------------------------------------------------------------- 3. Flask
echo -e "${C}[3/5] Flask (interface web)${N}"
if python3 -c "import flask" >/dev/null 2>&1; then
  echo -e "  ${G}✓${N} flask (ja instalado)"
else
  printf "  ${Y}→${N} instalando flask... "
  python3 -m pip install --upgrade pip >/dev/null 2>&1 || true
  if python3 -m pip install flask >/dev/null 2>&1 && python3 -c "import flask" >/dev/null 2>&1; then
    echo -e "${G}ok${N}"
  else
    echo -e "${R}FALHOU${N} - tente: pkg install python-pip && pip install flask"
  fi
fi

# ------------------------------------------------- 4. reservas (JAR portatil)
echo -e "${C}[4/5] Reservas portateis (so se faltar algo)${N}"

if ! tem apktool; then
  echo -e "  ${Y}→${N} apktool nao veio do repositorio. Baixando o JAR oficial..."
  if curl -fsSL -o "$TOOLS/apktool.jar" "$APKTOOL_URL"; then
    cat > "$PREFIX/bin/apktool" <<EOF
#!$PREFIX/bin/bash
exec java -jar "$TOOLS/apktool.jar" "\$@"
EOF
    chmod +x "$PREFIX/bin/apktool" 2>/dev/null || true
    tem apktool && echo -e "  ${G}✓${N} apktool instalado via JAR (só precisa do Java)" \
                || echo -e "  ${R}✕${N} falhou ao criar o apktool"
  else
    echo -e "  ${R}✕${N} nao consegui baixar (verifique a internet)"
  fi
else
  echo -e "  ${G}✓${N} apktool ok"
fi

if ! tem apksigner; then
  echo -e "  ${Y}→${N} apksigner nao veio do repositorio. Baixando assinador portatil..."
  if curl -fsSL -o "$TOOLS/uber-apk-signer.jar" "$UBER_URL"; then
    echo -e "  ${G}✓${N} assinador portatil pronto (o app usa sozinho)"
  else
    echo -e "  ${R}✕${N} nao consegui baixar o assinador"
  fi
else
  echo -e "  ${G}✓${N} apksigner ok"
fi

# ---------------------------------------------------------------- 5. atalho
echo -e "${C}[5/5] Atalho do comando${N}"
DIR="$(cd "$(dirname "$0")" && pwd)"
BIN="$PREFIX/bin/apkeditor"
cat > "$BIN" <<EOF
#!$PREFIX/bin/bash
cd "$DIR"
exec python3 app.py
EOF
chmod +x "$BIN" 2>/dev/null || true
echo -e "  ${G}✓${N} comando 'apkeditor' criado"

# ---------------------------------------------------------------- relatorio
echo
echo -e "${C}==================== RELATORIO ====================${N}"
falta=""
for t in java apktool zipalign apksigner keytool aapt aapt2; do
  if tem "$t"; then echo -e "  ${G}✓${N} $t"; else echo -e "  ${R}✕${N} $t"; falta="$falta $t"; fi
done
python3 -c "import PIL" >/dev/null 2>&1 && echo -e "  ${G}✓${N} Pillow" || { echo -e "  ${R}✕${N} Pillow"; falta="$falta Pillow"; }
python3 -c "import flask" >/dev/null 2>&1 && echo -e "  ${G}✓${N} Flask" || { echo -e "  ${R}✕${N} Flask"; falta="$falta Flask"; }
[ -f "$TOOLS/uber-apk-signer.jar" ] && echo -e "  ${G}✓${N} assinador portatil (reserva)"

if [ -n "$falta" ]; then
  echo
  echo -e "${Y}Faltando:${falta}${N}"
  echo -e "${Y}O painel tem um botao \"Instalar ferramentas\" que tenta de novo.${N}"
else
  echo
  echo -e "${G}Tudo instalado! 🎉${N}"
fi

echo
echo -e "  Para abrir:  ${Y}apkeditor${N}"
echo -e "  No navegador: ${Y}http://127.0.0.1:5000${N}"
echo -e "  Seus APKs em: ${Y}/storage/emulated/0/ApkEditor${N}"
echo
