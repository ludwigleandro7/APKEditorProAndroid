/* APK Editor Pro - front-end
   Fluxos de 1 toque:
   - tocar numa imagem  -> abre o seletor e troca na hora
   - tocar numa fonte   -> abre o seletor e troca na hora
   - tocar numa URL     -> digita o novo valor e ja substitui
*/
const S = { apk:null, projeto:null, urls:[], servidores:[], imagens:[], fontes:[], strings:[],
            alvoImg:null, alvoFonte:null, alvoLayout:null, splash:{}, cores:null, categorias:{},
            ruins:[], problemas:[], avisos:[] };

const $ = (id) => document.getElementById(id);
const el = (t, c, h) => { const e=document.createElement(t); if(c)e.className=c; if(h!=null)e.innerHTML=h; return e; };
const fmt = (n) => n>1048576 ? (n/1048576).toFixed(2)+" MB" : (n/1024).toFixed(0)+" KB";
const esc = (s) => String(s==null?"":s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const previewUrl = (rel) => `/api/preview?path=${encodeURIComponent(S.projeto)}&rel=${encodeURIComponent(rel)}`;

async function api(url, opt){
  const r = await fetch(url, opt);
  const j = await r.json().catch(()=>({ok:false,erro:"resposta inválida do servidor"}));
  if(!j.ok) throw new Error(j.erro || "erro desconhecido");
  return j;
}
function mostrarLog(id, txt){ const p=$(id); p.classList.remove("hidden"); p.textContent = txt; p.scrollTop = p.scrollHeight; }
function addLog(id, txt){ const p=$(id); p.classList.remove("hidden"); p.textContent += txt; p.scrollTop = p.scrollHeight; }

/* barra de aviso rápida no topo */
let toastTimer = null;
function toast(msg, tipo){
  let t = $("toast");
  if(!t){ t = el("div","toast"); t.id = "toast"; document.body.appendChild(t); }
  t.className = "toast " + (tipo||"ok");
  t.innerHTML = msg;
  t.style.display = "block";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>{ t.style.display = "none"; }, 4200);
}

/* ---------------- status / ferramentas ---------------- */
async function carregarStatus(){
  try{
    const j = await api("/api/status");
    $("apkDir").textContent = j.apk_dir;
    const t = j.tools;
    const nomes = {java:"Java",apktool:"apktool",zipalign:"zipalign",apksigner:"apksigner",keytool:"keytool",aapt:"aapt",aapt2:"aapt2",pillow:"Pillow"};
    $("tools").innerHTML = Object.keys(nomes).map(k =>
      `<span class="pill ${t[k]?"on":"off"}">${t[k]?"✓":"✕"} ${nomes[k]}</span>`).join("");
    if(t.assinador && t.assinador !== "apksigner"){
      $("tools").appendChild(el("span","pill on","✓ assinador: "+t.assinador));
    }
    if(!t.ok) $("tools").appendChild(el("span","pill off","Faltam: "+t.missing.join(", ")));

    // card de ferramentas faltando
    const card = $("cardFerramentas");
    if(!t.ok){
      card.classList.remove("hidden");
      const faltam = t.missing || [];
      $("faltaLista").innerHTML = faltam.map(m=>{
        const dica = {
          apktool: "abre e recompila o APK",
          apksigner: "assina o APK para instalar no celular",
          java: "roda o apktool e o assinador",
          zipalign: "alinha o APK",
          keytool: "cria a chave de assinatura",
        }[m] || "";
        return `<div class="falta-item"><b>${esc(m)}</b><span>${esc(dica)}</span></div>`;
      }).join("");
    } else {
      card.classList.add("hidden");
    }

    if(!j.apk_dir_exists){
      $("apkList").innerHTML = `<div class="empty">A pasta <b>${esc(j.apk_dir)}</b> não existe.<br>
        Crie a pasta e coloque os APKs nela, ou rode <code>termux-setup-storage</code>.</div>`;
    }
  }catch(e){ console.error(e); }
}

async function instalarFerramentas(){
  const btn = $("btnInstalar");
  btn.disabled = true; btn.textContent = "⏳ Instalando… (pode demorar alguns minutos)";
  $("logInstalar").classList.remove("hidden");
  $("logInstalar").textContent = "Iniciando instalação…\n";
  try{
    const {job} = await api("/api/instalar",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({repos:true})});
    const res = await acompanhar(job, "logInstalar", null);
    const st = res.status || {};
    addLog("logInstalar", "\n" + (st.ok ? "✔ Tudo pronto!" : "⚠ Ainda faltam: " + (st.missing||[]).join(", ")) + "\n");
    toast(st.ok ? "✔ Ferramentas instaladas!" : "⚠ Ainda falta: " + (st.missing||[]).join(", "),
          st.ok ? "ok" : "erro");
    await carregarStatus();
  }catch(e){
    addLog("logInstalar", "\n[ERRO] " + e.message + "\n");
    toast("✖ " + e.message, "erro");
  }
  btn.disabled = false; btn.textContent = "⬇ Instalar ferramentas automaticamente";
}

/* ---------------- etapa 1 ---------------- */
async function carregarApks(){
  const box = $("apkList");
  try{
    const j = await api("/api/apks");
    if(!j.apks.length){ box.innerHTML = `<div class="empty">Nenhum .apk encontrado na pasta.</div>`; return; }
    box.innerHTML = "";
    j.apks.forEach(a=>{
      const d = el("div","apk");
      d.innerHTML = `<div class="ic">📦</div>
        <div style="flex:1"><div class="nm">${esc(a.name)}</div><div class="mt">${fmt(a.size)}</div></div>
        <div class="mt">selecionar ▸</div>`;
      d.onclick = ()=>selecionarApk(a, d);
      box.appendChild(d);
    });
  }catch(e){ box.innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}

async function selecionarApk(a, node){
  document.querySelectorAll(".apk").forEach(x=>x.classList.remove("sel"));
  node.classList.add("sel");
  S.apk = a;
  $("cardAnalise").classList.remove("hidden");
  $("apkInfo").innerHTML = `<div class="info-item"><div class="k">Arquivo</div><div class="v">${esc(a.name)}</div></div>
    <div class="info-item"><div class="k">Tamanho</div><div class="v">${fmt(a.size)}</div></div>
    <div class="info-item"><div class="k">Analisando…</div><div class="v">aguarde</div></div>`;
  try{
    const j = await api("/api/info?apk="+encodeURIComponent(a.path));
    const i = j.info;
    $("apkInfo").innerHTML = [
      ["Arquivo", i.file], ["Pacote", i.package||"—"], ["Nome do app", i.label||"—"],
      ["Versão", (i.versionName||"—")+"  (code "+(i.versionCode||"—")+")"],
      ["Android mín.", i.minSdk||"—"], ["Android alvo", i.targetSdk||"—"],
      ["Ícone", i.icon||"—"], ["Tamanho", fmt(a.size)],
    ].map(([k,v])=>`<div class="info-item"><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div></div>`).join("");
  }catch(e){ $("apkInfo").innerHTML = `<div class="info-item"><div class="k">Erro</div><div class="v">${esc(e.message)}</div></div>`; }
  $("cardEditor").classList.add("hidden");
  $("cardBuild").classList.add("hidden");
  $("logDecomp").classList.add("hidden");
  $("cardAnalise").scrollIntoView({behavior:"smooth"});
}

/* ---------------- etapa 2 ---------------- */
async function decompilar(){
  if(!S.apk) return;
  const btn = $("btnDecomp"); btn.disabled = true; btn.textContent = "⏳ Decompilando…";
  $("logDecomp").classList.remove("hidden");
  $("logDecomp").textContent = "Abrindo o APK com o apktool…\n";
  try{
    const {job} = await api("/api/decompilar",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({apk:S.apk.path})});
    await acompanhar(job, "logDecomp", (res)=>abrirProjeto(res.project));
  }catch(e){ addLog("logDecomp","\n[ERRO] "+e.message); }
  btn.disabled = false; btn.textContent = "⚙ Decompilar";
}

async function acompanhar(jid, logId, aoTerminar){
  let since = 0;
  while(true){
    const j = await api(`/api/job/${jid}?since=${since}`);
    const job = j.job;
    if(job.log.length) addLog(logId, job.log.join("\n")+"\n");
    since = job.next;
    if(job.status === "concluido"){ if(aoTerminar) aoTerminar(job.result); return job.result; }
    if(job.status === "erro") throw new Error(job.error || "falhou");
    await new Promise(r=>setTimeout(r,700));
  }
}

/* ---------------- etapa 3 ---------------- */
async function abrirProjeto(projectPath){
  if(projectPath) S.projeto = projectPath;
  const j = await api("/api/projeto?path="+encodeURIComponent(S.projeto));
  S.info = j.info; S.launcher = j.launcher||[]; S.backgrounds = j.backgrounds||[];
  S.splash = j.splash||{}; S.ruins = j.ninepatch_ruins||[];
  S.problemas = j.problemas||[]; S.avisos = j.avisos||[];
  $("cardEditor").classList.remove("hidden");
  $("cardBuild").classList.remove("hidden");
  $("projNome").textContent = j.info.nome;
  $("novoNome").value = j.info.label || "";
  $("novaVerName").value = j.info.versionName || "";
  $("novaVerCode").value = j.info.versionCode || "";
  $("novoPacote").value = j.info.package || "";
  $("nomeSaida").value = j.info.nome + "-editado";
  renderProblemas();
  renderLauncher(); renderBackgrounds(); renderSplash();
  carregarServidores(); carregarImagens(); carregarCores(); carregarFontes(); carregarStrings();
  if(!$("regras").children.length){ addRegra(); addRegra(); }
  $("cardEditor").scrollIntoView({behavior:"smooth"});
}

/* painel de problemas reais (checagem local, sem aapt2) */
function renderProblemas(){
  const box = $("listaProblemas");
  const tem = S.problemas.length || S.ruins.length;
  if(!tem){ box.classList.add("hidden"); box.innerHTML = ""; return; }
  box.classList.remove("hidden");
  const porTipo = {};
  S.problemas.forEach(p => { (porTipo[p.tipo] = porTipo[p.tipo] || []).push(p); });
  let html = `<h3>⚠ ${S.problemas.length} recurso(s) com problema</h3><ul>`;
  S.problemas.slice(0,14).forEach(p =>
    html += `<li><b>${esc(p.arquivo)}</b><br>${esc(p.detalhe)}</li>`);
  if(S.problemas.length > 14) html += `<li>… e mais ${S.problemas.length-14}</li>`;
  html += `</ul>`;
  if(porTipo["nome"] && porTipo["nome"].length){
    html += `<div class="dica">${porTipo["nome"].length} recurso(s) com <b>nome inválido</b>
      (o aapt2 recusa nomes começando com <code>$</code>).
      <button class="btn" style="margin-top:8px" onclick="corrigirNomes()">🏷 Corrigir nomes agora</button></div>`;
  }
  if(porTipo["9patch"] && porTipo["9patch"].length){
    html += `<div class="dica">${porTipo["9patch"].length} arquivo(s) <b>.9.png</b> com borda inválida.
      <button class="btn" style="margin-top:8px" onclick="consertar9()">🩹 Consertar 9-patch agora</button></div>`;
  }
  if(S.avisos.length){
    html += `<div class="dica" style="border-top-color:#3a3a1a;color:#ffe27a">
      ${S.avisos.length} aviso(s) de nome de arquivo (podem ou não quebrar o build).</div>`;
  }
  box.innerHTML = html;
}

document.querySelectorAll(".tab").forEach(t=>{
  t.onclick = ()=>{
    document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
    document.querySelectorAll(".tabpane").forEach(x=>x.classList.remove("active"));
    t.classList.add("active");
    $("tab-"+t.dataset.tab).classList.add("active");
  };
});

/* ---------------- BUSCA de endereco (estilo APK Editor) ---------------- */
let buscaAlvo = null;
async function buscarEndereco(){
  const termo = ($("buscaSrv").value||"").trim();
  const box = $("buscaResultado");
  if(termo.length < 3){ box.innerHTML = `<div class="empty">Digite pelo menos 3 caracteres.</div>`; return; }
  box.innerHTML = `<div class="empty">Buscando “${esc(termo)}”…</div>`;
  buscaAlvo = null;
  try{
    const j = await api("/api/buscar-endereco?path="+encodeURIComponent(S.projeto)+"&q="+encodeURIComponent(termo));
    S.busca = j;
    if(!j.servidores.length && !j.ocorrencias.length){
      box.innerHTML = `<div class="empty">Nada encontrado com “${esc(termo)}”.</div>`; return;
    }
    let h = `<div class="busca-res">`;
    if(j.servidores.length){
      h += `<p class="hint small"><b>${j.servidores.length} servidor(es)</b> — ${j.total} ocorrência(s) em ${j.arquivos} arquivo(s):</p>`;
      j.servidores.forEach((s,i)=>{
        h += `<div class="busca-item" data-tipo="servidor" data-i="${i}">
            <div class="u"><b>${esc(s.servidor)}</b><br><span class="f">${s.urlCount} endereço(s) · ${s.fileCount} arquivo(s)</span></div>
            <div class="c">${s.count}×</div></div>`;
      });
    }
    if(j.urls.length){
      h += `<p class="hint small" style="margin-top:10px">Endereços exatos:</p>`;
      j.urls.slice(0,12).forEach((u,i)=>{
        h += `<div class="busca-item" data-tipo="url" data-i="${i}">
            <div class="u">${esc(u.url)}<br><span class="f">${u.fileCount} arquivo(s)</span></div>
            <div class="c">${u.count}×</div></div>`;
      });
    }
    h += `</div>`;
    box.innerHTML = h;
    box.querySelectorAll(".busca-item").forEach(el2=>{
      el2.onclick = ()=>{
        box.querySelectorAll(".busca-item").forEach(x=>x.classList.remove("sel"));
        el2.classList.add("sel");
        const tipo = el2.dataset.tipo, i = +el2.dataset.i;
        buscaAlvo = tipo === "servidor" ? j.servidores[i].servidor : j.urls[i].url;
        mostrarTrocaBusca(buscaAlvo, tipo === "servidor" ? j.servidores[i] : j.urls[i]);
      };
    });
  }catch(e){ box.innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
function mostrarTrocaBusca(alvo, info){
  const n = info.count || 0, fa = info.fileCount || 0;
  const box = $("buscaResultado");
  let antigo = box.querySelector(".busca-troca");
  if(antigo) antigo.remove();
  const d = el("div","busca-troca");
  d.innerHTML = `<div class="alvo">${esc(alvo)}</div>
    <p class="hint small">Vai trocar <b>${n} ocorrência(s)</b> em <b>${fa} arquivo(s)</b>.</p>
    <div class="row" style="margin-bottom:0">
      <input id="buscaNovo" placeholder="novo endereço, ex: http://auth.urlsync.gy:80">
      <button class="btn" onclick="trocarBusca()">⇄ Trocar tudo</button>
    </div>`;
  box.appendChild(d);
  setTimeout(()=>{ const i=$("buscaNovo"); if(i){ i.focus();
    i.onkeydown = e => { if(e.key==="Enter") trocarBusca(); }; } }, 60);
}
async function trocarBusca(){
  const novo = ($("buscaNovo") ? $("buscaNovo").value : "").trim();
  if(!buscaAlvo){ toast("Escolha um resultado da busca primeiro.", "erro"); return; }
  if(!novo){ toast("Digite o novo endereço.", "erro"); return; }
  if(novo === buscaAlvo){ toast("É o mesmo endereço — nada mudou.", "erro"); return; }
  await aplicarTroca(buscaAlvo, novo, "endereço");
  $("buscaSrv").value = novo;
  buscarEndereco();
}

/* ---------------- servidores: agrupados por SERVIDOR ---------------- */
async function carregarServidores(){
  $("srvList").innerHTML = `<div class="empty">Escaneando…</div>`;
  try{
    const j = await api("/api/servidores?path="+encodeURIComponent(S.projeto));
    S.servidores = j.servidores; renderServidores();
  }catch(e){ $("srvList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
function renderServidores(){
  const q = ($("filtroUrl").value||"").toLowerCase();
  const list = (S.servidores||[]).filter(s=>!q || s.servidor.toLowerCase().includes(q));
  if(!list.length){ $("srvList").innerHTML = `<div class="empty">Nenhum servidor encontrado.</div>`; return; }
  const box = $("srvList"); box.innerHTML = "";
  list.forEach(s=>{
    const d = el("div","item");
    d.innerHTML = `<div class="u"><b>${esc(s.servidor)}</b><br>
        <span class="mini">${s.urlCount} endereço(s) · ${s.count} ocorrência(s) · ${s.fileCount} arquivo(s)</span></div>
      <button class="btn" style="padding:6px 12px;flex:0 0 auto">trocar</button>`;
    d.onclick = ()=>abrirTrocaServidor(s);
    box.appendChild(d);
  });
}

/* --- janela de confirmação --- */
let modalOk = null;
function abrirModal({titulo, corpo, placeholder, valor, textoOk, onOk}){
  $("modalTitle").innerHTML = titulo;
  $("modalBody").innerHTML = corpo;
  const inp = $("modalInput");
  inp.placeholder = placeholder || "";
  inp.value = valor || "";
  $("modalOk").textContent = textoOk || "Confirmar";
  modalOk = onOk;
  $("modal").classList.remove("hidden");
  setTimeout(()=>inp.focus(), 60);
}
function fecharModal(){ $("modal").classList.add("hidden"); modalOk = null; }
$("modalOk").onclick = async ()=>{
  const fn = modalOk;
  const v = $("modalInput").value.trim();
  if(!v){ toast("Digite o novo endereço.", "erro"); return; }
  fecharModal();
  if(fn) await fn(v);
};
$("modalInput").addEventListener("keydown", e=>{ if(e.key === "Enter") $("modalOk").click(); });

function abrirTrocaServidor(s){
  const urls = s.urls.slice(0, 12).map(u=>
    `<li>${esc(u.url)} <span style="color:var(--dim)">(${u.count}×)</span></li>`).join("");
  const mais = s.urls.length > 12 ? `<li>… e mais ${s.urls.length-12} endereço(s)</li>` : "";
  abrirModal({
    titulo: "⇄ Trocar servidor",
    corpo: `<div class="alvo">${esc(s.servidor)}</div>
      <p class="hint small">Vai trocar <b>${s.count} ocorrência(s)</b> em
        <b>${s.fileCount} arquivo(s)</b> — só deste servidor. Estes endereços serão afetados:</p>
      <ul class="lista-afetada">${urls}${mais}</ul>`,
    placeholder: "novo servidor, ex: http://auth.dnskode.com:80",
    textoOk: "⇄ Trocar tudo",
    onOk: (novo)=>aplicarTroca(s.servidor, novo, "servidor")
  });
}

function abrirTrocaUrl(u){
  abrirModal({
    titulo: "⇄ Trocar este endereço",
    corpo: `<div class="alvo">${esc(u.url)}</div>
      <p class="hint small">Vai trocar <b>${u.count} ocorrência(s)</b> em
        <b>${u.fileCount} arquivo(s)</b> — só este endereço, sem mexer no resto do servidor.</p>`,
    placeholder: "novo endereço",
    textoOk: "⇄ Trocar este",
    onOk: (novo)=>aplicarTroca(u.url, novo, "endereço")
  });
}

async function aplicarTroca(antigo, novo, oQue){
  if(novo === antigo){ toast("É o mesmo endereço — nada mudou.", "erro"); return; }
  toast("⏳ Trocando…", "ok");
  try{
    const j = await api("/api/substituir",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:S.projeto, regras:[{find:antigo, replace:novo, caseSensitive:true}]})});
    if(!j.ocorrencias){ toast("Nada encontrado para trocar.", "erro"); return; }
    toast(`✔ ${oQue} trocado — ${j.ocorrencias} ocorrência(s) em ${j.arquivos} arquivo(s)`, "ok");
    mostrarLog("logSub", `✔ ${oQue} trocado\n   de: ${antigo}\n   para: ${novo}\n   ${j.ocorrencias}× em ${j.arquivos} arquivo(s)\n`);
    carregarServidores();
  }catch(e){ toast("✖ " + e.message, "erro"); }
}

function toggleUrls(){
  const box = $("urlList"), row = $("urlFiltroRow"), btn = $("btnToggleUrls");
  const abrir = box.classList.contains("hidden");
  box.classList.toggle("hidden", !abrir);
  row.classList.toggle("hidden", !abrir);
  btn.textContent = abrir ? "Ocultar endereços" : "Mostrar todos os endereços";
  if(abrir && !S.urls) carregarUrls();
}

async function carregarUrls(){
  $("urlList").innerHTML = `<div class="empty">Escaneando…</div>`;
  try{
    const j = await api("/api/urls?path="+encodeURIComponent(S.projeto));
    S.urls = j.urls; renderUrls();
  }catch(e){ $("urlList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
function renderUrls(){
  const q = ($("filtroUrlFull").value||"").toLowerCase();
  const list = (S.urls||[]).filter(u=>!q || u.url.toLowerCase().includes(q));
  if(!list.length){ $("urlList").innerHTML = `<div class="empty">Nenhum endereço encontrado.</div>`; return; }
  const box = $("urlList"); box.innerHTML = "";
  list.forEach(u=>{
    const d = el("div","item");
    d.innerHTML = `<div class="u">${esc(u.url)}<br>
        <span class="mini">${esc(u.servidor)}</span></div>
      <div class="c">${u.count}×</div>`;
    d.onclick = ()=>abrirTrocaUrl(u);
    box.appendChild(d);
  });
}

function addRegra(f="",r=""){
  const w = el("div","reg");
  w.innerHTML = `<input placeholder="procurar" value="${esc(f)}">
                 <input placeholder="substituir" value="${esc(r)}">
                 <button class="del" title="remover">✕</button>`;
  w.querySelector(".del").onclick = ()=>w.remove();
  $("regras").appendChild(w);
}
function lerRegras(){
  return [...document.querySelectorAll("#regras .reg")].map(w=>{
    const i = w.querySelectorAll("input");
    return {find:i[0].value, replace:i[1].value};
  }).filter(r=>r.find);
}
async function substituirTodas(){
  const regras = lerRegras();
  if(!regras.length) return alert("Adicione pelo menos uma regra com o campo “procurar”.");
  await aplicarRegras(regras, true);
}
async function aplicarRegras(regras, cs){
  mostrarLog("logSub","Aplicando substituição…\n");
  try{
    const j = await api("/api/substituir",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:S.projeto, regras:regras.map(r=>({...r, caseSensitive:cs}))})});
    let out = `✔ ${j.ocorrencias} ocorrência(s) em ${j.arquivos} arquivo(s)\n`;
    j.detalhes.forEach(d=> out += `  • "${d.find}" → "${d.replace}"  :  ${d.ocorrencias}×  (${d.arquivos} arq.)\n`);
    mostrarLog("logSub", out);
    toast(`✔ ${j.ocorrencias} ocorrência(s) trocada(s)`, "ok");
    carregarServidores();
  }catch(e){ addLog("logSub","\n[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}

/* ---------------- visual: galeria completa ---------------- */
function thumb(rel, tag){
  const d = el("div","thumb");
  const broken = S.ruins.includes(rel);
  const info = (S.imagens||[]).find(i=>i.path===rel);
  if(broken) d.classList.add("broken");
  const dims = info && info.w ? `${info.w}×${info.h}` : (info? fmt(info.size) : "");
  const cat = info ? info.categoria : "";
  const rot = info ? info.rotulo : (tag||"");
  d.innerHTML = `<div class="box-img"><img loading="lazy" src="${previewUrl(rel)}" alt=""></div>
    <div class="nm">${esc(rel.split("/").pop())}</div>
    <div class="dims">${esc(dims)}</div>
    ${cat?`<div class="cat cat-${cat}" title="${esc(info.dica)}">${esc(rot)}</div>`:(tag?`<div class="cat cat-outra">${esc(tag)}</div>`:"")}
    ${broken?`<div class="tag">⚠ 9-patch inválido</div>`:""}`;
  return d;
}
function renderLauncher(){
  const box = $("launcherList"); box.innerHTML = "";
  if(!S.launcher.length){ box.innerHTML = `<div class="empty">Nenhum ícone identificado.</div>`; }
  S.launcher.forEach(p=>{
    const d = thumb(p, "ícone");
    d.onclick = ()=>pedirImagem(p, d);
    box.appendChild(d);
  });
  $("cIc").textContent = S.launcher.length;
}
function renderBackgrounds(){
  const box = $("bgList"); box.innerHTML = "";
  const fundos = (S.imagens||[]).filter(i=>i.categoria==="fundo").map(i=>i.path);
  const lista = fundos.length ? fundos : (S.backgrounds||[]);
  if(!lista.length) box.innerHTML = `<div class="empty">Nenhum fundo detectado.</div>`;
  lista.forEach(p=>{
    const d = thumb(p, "fundo");
    d.onclick = ()=>pedirImagem(p, d);
    box.appendChild(d);
  });
  $("cFundo").textContent = lista.length;
}
function renderSplashGrid(){
  const box = $("splashImgsGrid"); if(!box) return;
  box.innerHTML = "";
  const sp = (S.imagens||[]).filter(i=>i.categoria==="splash").map(i=>i.path);
  const lista = sp.length ? sp : (S.splash.imagens||[]);
  if(!lista.length) box.innerHTML = `<div class="empty">Nenhuma imagem de splash detectada.</div>`;
  lista.forEach(p=>{
    const d = thumb(p, "splash");
    d.onclick = ()=>pedirImagem(p, d);
    box.appendChild(d);
  });
  $("cSplash").textContent = lista.length;
}
async function carregarImagens(){
  try{
    const j = await api("/api/imagens?path="+encodeURIComponent(S.projeto));
    S.imagens = j.imagens; S.categorias = j.categorias;
    renderImagens(); renderLauncher(); renderBackgrounds(); renderSplashGrid(); renderSplash();
  }catch(e){ $("imgList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
function renderImagens(){
  const q = ($("filtroImg").value||"").toLowerCase();
  const cat = $("filtroCat").value;
  const list = (S.imagens||[]).filter(i=>
    (!cat || i.categoria===cat) &&
    (!q || i.path.toLowerCase().includes(q)));
  $("cTodas").textContent = (S.imagens||[]).length;
  if(!list.length){ $("imgList").innerHTML = `<div class="empty">Nenhuma imagem encontrada.</div>`; return; }
  const box = $("imgList"); box.innerHTML = "";
  const rot = {icone:"ícone", fundo:"fundo", splash:"splash", outra:""};
  list.slice(0, 900).forEach(i=>{
    const d = thumb(i.path, rot[i.categoria]);
    d.onclick = ()=>pedirImagem(i.path, d);
    box.appendChild(d);
  });
}

/* toque -> marca -> abre o seletor de arquivos na hora */
function pedirImagem(rel, node){
  document.querySelectorAll(".thumb").forEach(x=>x.classList.remove("sel"));
  document.querySelectorAll("#imgList .item").forEach(x=>x.classList.remove("sel"));
  if(node) node.classList.add("sel");
  S.alvoImg = rel;
  toast(`Trocando: <b>${esc(rel.split("/").pop())}</b><br>escolha a nova imagem…`, "ok");
  const inp = $("fileImg");
  inp.value = "";                 // permite escolher o mesmo arquivo de novo
  inp.click();                    // abre o seletor imediatamente
}

$("fileImg").addEventListener("change", ()=>{ if($("fileImg").files[0]) enviarImagem(); });

async function enviarImagem(){
  if(!S.alvoImg){ toast("Toque numa imagem primeiro.", "erro"); return; }
  const f = $("fileImg").files[0];
  if(!f) return;
  const fd = new FormData();
  fd.append("path", S.projeto);
  fd.append("target", S.alvoImg);
  if($("broadMode").checked) fd.append("broad", S.alvoImg.split("/").pop().split(".")[0]);
  fd.append("file", f);
  toast("⏳ Enviando e substituindo…", "ok");
  try{
    const j = await api("/api/upload",{method:"POST",body:fd});
    let out = j.substituidos ? `✔ ${j.quantidade} variante(s) trocada(s):\n  `+j.substituidos.join("\n  ")
                             : `✔ trocado: ${j.substituido}`;
    if(j.avisos && j.avisos.length) out += "\n  ["+j.avisos.join("; ")+"]";
    mostrarLog("logImg", out+"\n");
    toast(`✔ ${j.quantidade||1} arquivo(s) trocado(s)`, "ok");
    carregarImagens(); recarregarProblemas();
  }catch(e){ toast("✖ " + e.message, "erro"); addLog("logImg","\n[ERRO] "+e.message+"\n"); }
}
/* ---------------- CORES ---------------- */
function hexOk(v){ return /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(v||""); }

/* converte #AARRGGBB / #RRGGBB / #RGB para #RRGGBB (o <input type=color> so aceita RRGGBB) */
function paraRRGGBB(v){
  if(!hexOk(v)) return "#000000";
  let h = v.replace("#","").toUpperCase();
  if(h.length === 8) h = h.slice(2);          // descarta o alfa
  else if(h.length === 4) h = h.slice(1);     // descarta o alfa
  if(h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
  return "#" + h;
}
function corVisivel(v){
  if(!hexOk(v)) return "transparent";
  let h = v.replace("#","");
  if(h.length === 8) return "#" + h.slice(2);
  if(h.length === 4) return "#" + h.slice(1);
  if(h.length === 3) return "#" + h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
  return "#" + h;
}

async function carregarCores(){
  $("corTema").innerHTML = `<div class="empty">Carregando…</div>`;
  try{
    const j = await api("/api/cores?path="+encodeURIComponent(S.projeto));
    S.cores = j; renderCores();
  }catch(e){ $("corTema").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
  carregarGradientes();
}
function renderCores(){
  const c = S.cores || {nomeadas:[],valores:[],temas:[]};
  // cores nomeadas (colors.xml)
  $("cTema").textContent = c.nomeadas.length;
  const box = $("corTema"); box.innerHTML = "";
  if(!c.nomeadas.length) box.innerHTML = `<div class="empty">Nenhuma cor nomeada em colors.xml.</div>`;
  c.nomeadas.forEach(x=>{
    const d = el("div","cor-item");
    d.innerHTML = `<div class="cor-swatch"><i style="background:${corVisivel(x.valor)}"></i></div>
      <div class="cor-nome"><b>${esc(x.nome)}</b><span>${esc(x.valor)}</span></div>
      <div class="cor-meta">${x.usos} uso(s)</div>`;
    d.onclick = ()=>abrirCor({tipo:"nomeada", nome:x.nome, valor:x.valor});
    box.appendChild(d);
  });
  // atributos de tema
  $("cAtrib").textContent = c.temas.length;
  const box2 = $("corAtrib"); box2.innerHTML = "";
  if(!c.temas.length) box2.innerHTML = `<div class="empty">Nenhum atributo de tema detectado.</div>`;
  c.temas.forEach(x=>{
    const d = el("div","cor-item");
    const ehHex = hexOk(x.valor);
    d.innerHTML = `<div class="cor-swatch"><i style="background:${ehHex?corVisivel(x.valor):"#000"}"></i></div>
      <div class="cor-nome"><b>${esc(x.chave)}</b><span>${esc(x.valor)}</span>
        ${x.descricao?`<span style="display:block;color:var(--dim);font-size:10.5px;margin-top:3px">${esc(x.descricao)}</span>`:""}</div>
      <div class="cor-meta">${ehHex?"hex direto":"referência"}</div>`;
    if(ehHex) d.onclick = ()=>abrirCor({tipo:"valor", valor:x.valor, chave:x.chave});
    else d.style.opacity = ".7";
    box2.appendChild(d);
  });
  renderCoresValores();
}
function renderCoresValores(){
  const c = S.cores || {valores:[]};
  const q = ($("filtroCor").value||"").replace("#","").toUpperCase();
  const list = (c.valores||[]).filter(x=>!q || x.valor.includes(q));
  $("cVal").textContent = (c.valores||[]).length;
  const box = $("corValores"); box.innerHTML = "";
  if(!list.length){ box.innerHTML = `<div class="empty">Nenhum valor encontrado.</div>`; return; }
  list.slice(0,300).forEach(x=>{
    const d = el("div","cor-item");
    d.innerHTML = `<div class="cor-swatch"><i style="background:${corVisivel(x.valor)}"></i></div>
      <div class="cor-nome"><b>${esc(x.valor)}</b><span>${esc((x.files||[]).join(", ").slice(0,70))}</span></div>
      <div class="cor-meta">${x.count}×<br>${x.fileCount} arq.</div>`;
    d.onclick = ()=>abrirCor({tipo:"valor", valor:x.valor});
    box.appendChild(d);
  });
}

/* --- paleta Material Design completa --- */
const MATERIAL = {
  "Red":         ["#FFEBEE","#FFCDD2","#EF9A9A","#E57373","#EF5350","#F44336","#E53935","#D32F2F","#C62828","#B71C1C","#FF8A80","#FF5252","#FF1744","#D50000"],
  "Pink":        ["#FCE4EC","#F8BBD0","#F48FB1","#F06292","#EC407A","#E91E63","#D81B60","#C2185B","#AD1457","#880E4F","#FF80AB","#FF4081","#F50057","#C51162"],
  "Purple":      ["#F3E5F5","#E1BEE7","#CE93D8","#BA68C8","#AB47BC","#9C27B0","#8E24AA","#7B1FA2","#6A1B9A","#4A148C","#EA80FC","#E040FB","#D500F9","#AA00FF"],
  "Deep Purple": ["#EDE7F6","#D1C4E9","#B39DDB","#9575CD","#7E57C2","#673AB7","#5E35B1","#512DA8","#4527A0","#311B92","#B388FF","#7C4DFF","#651FFF","#6200EA"],
  "Indigo":      ["#E8EAF6","#C5CAE9","#9FA8DA","#7986CB","#5C6BC0","#3F51B5","#3949AB","#303F9F","#283593","#1A237E","#8C9EFF","#536DFE","#3D5AFE","#304FFE"],
  "Blue":        ["#E3F2FD","#BBDEFB","#90CAF9","#64B5F6","#42A5F5","#2196F3","#1E88E5","#1976D2","#1565C0","#0D47A1","#82B1FF","#448AFF","#2979FF","#2962FF"],
  "Light Blue":  ["#E1F5FE","#B3E5FC","#81D4FA","#4FC3F7","#29B6F6","#03A9F4","#039BE5","#0288D1","#0277BD","#01579B","#80D8FF","#40C4FF","#00B0FF","#0091EA"],
  "Cyan":        ["#E0F7FA","#B2EBF2","#80DEEA","#4DD0E1","#26C6DA","#00BCD4","#00ACC1","#0097A7","#00838F","#006064","#84FFFF","#18FFFF","#00E5FF","#00B8D4"],
  "Teal":        ["#E0F2F1","#B2DFDB","#80CBC4","#4DB6AC","#26A69A","#009688","#00897B","#00796B","#00695C","#004D40","#A7FFEB","#64FFDA","#1DE9B6","#00BFA5"],
  "Green":       ["#E8F5E9","#C8E6C9","#A5D6A7","#81C784","#66BB6A","#4CAF50","#43A047","#388E3C","#2E7D32","#1B5E20","#B9F6CA","#69F0AE","#00E676","#00C853"],
  "Light Green": ["#F1F8E9","#DCEDC8","#C5E1A5","#AED581","#9CCC65","#8BC34A","#7CB342","#689F38","#558B2F","#33691E","#CCFF90","#B2FF59","#76FF03","#64DD17"],
  "Lime":        ["#F9FBE7","#F0F4C3","#E6EE9C","#DCE775","#D4E157","#CDDC39","#C0CA33","#AFB42B","#9E9D24","#827717","#F4FF81","#EEFF41","#C6FF00","#AEEA00"],
  "Yellow":      ["#FFFDE7","#FFF9C4","#FFF59D","#FFF176","#FFEE58","#FFEB3B","#FDD835","#FBC02D","#F9A825","#F57F17","#FFFF8D","#FFFF00","#FFEA00","#FFD600"],
  "Amber":       ["#FFF8E1","#FFECB3","#FFE082","#FFD54F","#FFCA28","#FFC107","#FFB300","#FFA000","#FF8F00","#FF6F00","#FFE57F","#FFD740","#FFC400","#FFAB00"],
  "Orange":      ["#FFF3E0","#FFE0B2","#FFCC80","#FFB74D","#FFA726","#FF9800","#FB8C00","#F57C00","#EF6C00","#E65100","#FFD180","#FFAB40","#FF9100","#FF6D00"],
  "Deep Orange": ["#FBE9E7","#FFCCBC","#FFAB91","#FF8A65","#FF7043","#FF5722","#F4511E","#E64A19","#D84315","#BF360C","#FF9E80","#FF6E40","#FF3D00","#DD2C00"],
  "Brown":       ["#EFEBE9","#D7CCC8","#BCAAA4","#A1887F","#8D6E63","#795548","#6D4C41","#5D4037","#4E342E","#3E2723"],
  "Grey":        ["#FAFAFA","#F5F5F5","#EEEEEE","#E0E0E0","#BDBDBD","#9E9E9E","#757575","#616161","#424242","#212121"],
  "Blue Grey":   ["#ECEFF1","#CFD8DC","#B0BEC5","#90A4AE","#78909C","#607D8B","#546E7A","#455A64","#37474F","#263238"]
};
const MATERIAL_SHADES = ["50","100","200","300","400","500","600","700","800","900","A100","A200","A400","A700"];
const MATERIAL_KEYS = ["50","100","200","300","400","500","600","700","800","900"];

function aplicarCor(hex){
  $("corPicker").value = hex;
  $("corHex").value = hex;
  atualizarPreviewCor();
}
function renderMaterial(){
  const box = $("paletaMaterial");
  if(box.dataset.pronto) return;
  let h = "";
  Object.keys(MATERIAL).forEach(nome=>{
    const lista = MATERIAL[nome];
    h += `<div class="mat-grupo"><div class="mat-nome" style="background:${lista[5]}">${esc(nome)}</div>
      <div class="mat-shades">`;
    lista.forEach((hex, i)=>{
      const rot = i < MATERIAL_KEYS.length ? MATERIAL_KEYS[i] : MATERIAL_SHADES[i];
      h += `<div class="sw" style="background:${hex}" title="${esc(nome)} ${rot} · ${hex}" data-hex="${hex}"></div>`;
    });
    h += `</div></div>`;
  });
  box.innerHTML = h;
  box.dataset.pronto = "1";
  box.querySelectorAll(".sw").forEach(s=>{ s.onclick = ()=>aplicarCor(s.dataset.hex); });
}

/* --- paleta rapida (gerada) --- */
function hslHex(h, s, l){
  s/=100; l/=100;
  const k = n => (n + h/30) % 12;
  const a = s * Math.min(l, 1-l);
  const f = n => l - a * Math.max(-1, Math.min(k(n)-3, Math.min(9-k(n), 1)));
  const to = x => Math.round(255*x).toString(16).padStart(2,"0");
  return ("#" + to(f(0)) + to(f(8)) + to(f(4))).toUpperCase();
}
let PALETA = null;
function gerarPaleta(){
  if(PALETA) return PALETA;
  const out = [];
  // tons de cinza
  for(let i=0;i<=12;i++){ const v = Math.round(i*255/12).toString(16).padStart(2,"0");
    out.push("#" + v+v+v); }
  // 24 matizes x 8 luminosidades x 3 saturacoes
  const hues = [0,10,20,30,40,50,60,80,100,120,140,160,175,190,205,220,235,250,265,280,300,320,340,355];
  for(const h of hues)
    for(const l of [12,22,32,42,52,62,74,86])
      for(const s of [40,70,95])
        out.push(hslHex(h, s, l));
  PALETA = [...new Set(out.map(c => c.toUpperCase()))];
  return PALETA;
}
function renderPaleta(){
  renderMaterial();
  const box = $("paletaRapida");
  if(!box.dataset.pronto){
    let h = "";
    gerarPaleta().forEach(hex=>{ h += `<div class="sw" style="background:${hex}" title="${hex}" data-hex="${hex}"></div>`; });
    box.innerHTML = h;
    box.dataset.pronto = "1";
    box.querySelectorAll(".sw").forEach(s=>{ s.onclick = ()=>aplicarCor(s.dataset.hex); });
  }
}
document.querySelectorAll(".ptab").forEach(t=>{
  t.onclick = ()=>{
    document.querySelectorAll(".ptab").forEach(x=>x.classList.remove("active"));
    t.classList.add("active");
    const mat = t.dataset.p === "material";
    $("paletaMaterial").classList.toggle("hidden", !mat);
    $("paletaRapida").classList.toggle("hidden", mat);
  };
});

/* --- modal de cor --- */
let corAtual = null;
function abrirCor({tipo, nome, valor, chave}){
  corAtual = {tipo, nome, valor, chave};
  $("corTitulo").innerHTML = tipo === "nomeada"
    ? `🎨 Alterar a cor <b>${esc(nome)}</b>`
    : `🎨 Alterar o valor <b>${esc(valor)}</b>${chave?` <span style="color:var(--dim);font-size:11px">(${esc(chave)})</span>`:""}`;
  $("corInfo").innerHTML = tipo === "nomeada"
    ? `<p class="hint small">Cor definida em <code>res/values/colors.xml</code>. Mudando aqui, todo o app que usa
        <code>@color/${esc(nome)}</code> muda junto.</p>`
    : `<p class="hint small">Valor escrito direto nos arquivos. Vai trocar <b>todas</b> as ocorrências dele.</p>`;
  $("corAntes").style.background = corVisivel(valor);
  $("corAntes").textContent = corVisivel(valor).replace("#","").slice(0,6);
  $("corAntes").style.color = "#fff";
  $("corAntes").style.textShadow = "0 0 4px #000";
  $("corPicker").value = paraRRGGBB(valor);
  $("corHex").value = paraRRGGBB(valor);
  renderPaleta();
  atualizarPreviewCor();
  $("modalCor").classList.remove("hidden");
}
function fecharCor(){ $("modalCor").classList.add("hidden"); corAtual = null; }
function atualizarPreviewCor(){
  const v = $("corHex").value;
  const ok = hexOk(v);
  const chip = $("corDepois");
  chip.style.background = ok ? corVisivel(v) : "#111";
  chip.textContent = ok ? corVisivel(v).replace("#","").slice(0,6) : "?";
  chip.style.color = "#fff"; chip.style.textShadow = "0 0 4px #000";
}
$("corPicker").addEventListener("input", ()=>{ $("corHex").value = $("corPicker").value.toUpperCase(); atualizarPreviewCor(); });
$("corHex").addEventListener("input", ()=>{ if(hexOk($("corHex").value)) $("corPicker").value = paraRRGGBB($("corHex").value); atualizarPreviewCor(); });

$("corOk").onclick = async ()=>{
  if(!corAtual) return;
  const nova = ($("corHex").value||"").trim().toUpperCase();
  if(!hexOk(nova)){ toast("Cor inválida. Use #RRGGBB ou #AARRGGBB", "erro"); return; }
  const glob = $("corGlobal").checked;
  const alvo = corAtual;
  fecharCor();
  toast("⏳ Aplicando cor…", "ok");
  try{
    let j;
    if(alvo.tipo === "nomeada"){
      j = await api("/api/cor",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({path:S.projeto, nome:alvo.nome, nova, global:glob})});
      const r = j.resultado;
      mostrarLog("logCor", `✔ ${r.nome}: ${(r.antigos||[]).join(", ")} → ${r.nova}\n` +
        `   ${r.declaracoes} declaração(ões), ${r.ocorrencias} ocorrência(s) do valor antigo\n`);
      toast(`✔ ${alvo.nome} → ${r.nova}`, "ok");
    } else {
      j = await api("/api/cor-valor",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({path:S.projeto, antiga:alvo.valor, nova})});
      const r = j.resultado;
      mostrarLog("logCor", `✔ ${r.antiga} → ${r.nova}: ${r.ocorrencias} ocorrência(s) em ${r.arquivos} arquivo(s)\n`);
      toast(`✔ ${r.antiga} → ${r.nova} (${r.ocorrencias}×)`, "ok");
    }
    carregarCores();
  }catch(e){ toast("✖ "+e.message, "erro"); addLog("logCor","[ERRO] "+e.message+"\n"); }
};

/* ---------------- GRADIENTES ---------------- */
const GRAD_PRESETS = [
  ["Neon",      "#00FF88", "#0066FF"], ["Sunset",   "#FF512F", "#DD2476"],
  ["Oceano",    "#2193B0", "#6DD5ED"], ["Roxo",     "#8E2DE2", "#4A00E0"],
  ["Fogo",      "#F12711", "#F5AF19"], ["Menta",    "#00B09B", "#96C93D"],
  ["Noite",     "#232526", "#414345"], ["Candy",    "#FF9A9E", "#FAD0C4"],
  ["Aurora",    "#00C9FF", "#92FE9D"], ["Cereja",   "#EB3349", "#F45C43"],
  ["Anochecer", "#0F2027", "#2C5364"], ["Uva",      "#6A11CB", "#2575FC"],
  ["Pessego",   "#FFE259", "#FFA751"], ["Esmeralda","#0BA360", "#3CBA92"],
  ["Rubi",      "#C33764", "#1D2671"], ["Citrico",  "#FDC830", "#F37335"],
  ["Gelo",      "#83A4D4", "#B6FBFF"], ["Chocolate","#3E2723", "#8D6E63"],
  ["Cyberpunk", "#FC00FF", "#00DBDE"], ["Dourado",  "#F7971E", "#FFD200"],
  ["Grafite",   "#283048", "#859398"], ["Coracao",  "#ED213A", "#93291E"],
  ["Tropical",  "#11998E", "#38EF7D"], ["Lavanda",  "#9796F0", "#FBC7D4"]
];
let gradAtual = null;

async function carregarGradientes(){
  try{
    const j = await api("/api/gradientes?path="+encodeURIComponent(S.projeto));
    S.gradientes = j.gradientes; renderGradientes();
  }catch(e){ $("gradList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
function renderGradientes(){
  const g = S.gradientes || [];
  $("cGrad").textContent = g.length;
  const box = $("gradList"); box.innerHTML = "";
  if(!g.length){ box.innerHTML = `<div class="empty">Nenhum gradiente encontrado no app.</div>`; return; }
  g.slice(0,120).forEach((x,i)=>{
    const a = hexOk(x.startColor)?corVisivel(x.startColor):"#111";
    const b = hexOk(x.endColor)?corVisivel(x.endColor):"#333";
    const d = el("div","cor-item");
    d.innerHTML = `<div class="cor-swatch grad"><i style="background:linear-gradient(90deg,${a},${b})"></i></div>
      <div class="cor-nome"><b>${esc(x.arquivo.split("/").pop())}</b>
        <span>${esc(x.startColor||"?")} → ${esc(x.endColor||"?")}${x.angle?"  ·  "+esc(x.angle)+"°":""}</span></div>
      <div class="cor-meta">${esc(x.type)}</div>`;
    d.onclick = ()=>abrirGrad(x, i);
    box.appendChild(d);
  });
}
function abrirGrad(x, idx){
  gradAtual = {g:x, idx};
  $("gradInfo").innerHTML = `<div class="alvo">${esc(x.arquivo)}</div>
    <p class="hint small">Gradiente nº ${idx+1} deste arquivo.</p>`;
  $("gradStart").value = hexOk(x.startColor) ? paraRRGGBB(x.startColor) : "#00ff88";
  $("gradEnd").value   = hexOk(x.endColor)   ? paraRRGGBB(x.endColor)   : "#0066ff";
  $("gradAngle").value = x.angle || 0;
  $("gradTipo").value  = x.type || "linear";
  renderGradPresets();
  atualizarGradPreview();
  $("modalGrad").classList.remove("hidden");
}
function fecharGrad(){ $("modalGrad").classList.add("hidden"); gradAtual = null; }
function atualizarGradPreview(){
  $("gradPreview").style.background =
    `linear-gradient(90deg, ${$("gradStart").value}, ${$("gradEnd").value})`;
}
function renderGradPresets(){
  const box = $("gradPresets");
  if(box.dataset.pronto) return;
  box.innerHTML = GRAD_PRESETS.map(([n,a,b],i)=>`
    <div class="gp" data-i="${i}" title="${esc(n)}"
         style="background:linear-gradient(135deg,${a},${b})"></div>`).join("");
  box.dataset.pronto = "1";
  box.querySelectorAll(".gp").forEach(s=>{
    s.onclick = ()=>{
      const [n,a,b] = GRAD_PRESETS[+s.dataset.i];
      $("gradStart").value = a; $("gradEnd").value = b;
      atualizarGradPreview();
      toast(`Gradiente “${esc(n)}” selecionado`, "ok");
    };
  });
}
$("gradStart").addEventListener("input", atualizarGradPreview);
$("gradEnd").addEventListener("input", atualizarGradPreview);
$("gradOk").onclick = async ()=>{
  if(!gradAtual) return;
  const {g, idx} = gradAtual;
  const start = $("gradStart").value.toUpperCase();
  const end   = $("gradEnd").value.toUpperCase();
  const angle = $("gradAngle").value;
  const tipo  = $("gradTipo").value;
  fecharGrad();
  toast("⏳ Aplicando gradiente…", "ok");
  try{
    await api("/api/gradiente",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:S.projeto, arquivo:g.arquivo, index:g.index,
                           start, end, angle, tipo})});
    mostrarLog("logCor", `✔ gradiente em ${g.arquivo}: ${start} → ${end} (${angle}°, ${tipo})\n`);
    toast(`✔ gradiente aplicado`, "ok");
    carregarGradientes();
  }catch(e){ toast("✖ "+e.message, "erro"); addLog("logCor","[ERRO] "+e.message+"\n"); }
};

/* ---------------- fontes: toque = troca imediata ---------------- */
async function carregarFontes(){
  try{
    const j = await api("/api/fontes?path="+encodeURIComponent(S.projeto));
    S.fontes = j.fontes;
    const box = $("fontList"); box.innerHTML = "";
    if(!j.fontes.length){ box.innerHTML = `<div class="empty">Nenhuma fonte embutida.</div>`; return; }
    j.fontes.forEach(f=>{
      const d = el("div","item");
      d.innerHTML = `<div class="u">🔤 ${esc(f.path)}</div><div class="mini">${fmt(f.size)}</div>`;
      d.onclick = ()=>{
        document.querySelectorAll("#fontList .item").forEach(x=>x.classList.remove("sel"));
        d.classList.add("sel"); S.alvoFonte = f.path;
        toast(`Trocando fonte: <b>${esc(f.name)}</b><br>escolha o arquivo…`, "ok");
        const inp = $("fileFonte"); inp.value = ""; inp.click();
      };
      box.appendChild(d);
    });
  }catch(e){ $("fontList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
$("fileFonte").addEventListener("change", ()=>{ if($("fileFonte").files[0]) enviarFonte(); });

async function enviarFonte(){
  if(!S.alvoFonte){ toast("Toque numa fonte primeiro.", "erro"); return; }
  const f = $("fileFonte").files[0];
  if(!f) return;
  const fd = new FormData();
  fd.append("path", S.projeto); fd.append("target", S.alvoFonte); fd.append("file", f);
  toast("⏳ Enviando fonte…", "ok");
  try{
    const j = await api("/api/upload",{method:"POST",body:fd});
    mostrarLog("logFonte","✔ substituída: "+j.substituido+"\n");
    toast("✔ fonte trocada", "ok");
  }catch(e){ toast("✖ " + e.message, "erro"); addLog("logFonte","\n[ERRO] "+e.message+"\n"); }
}

/* ---------------- identidade ---------------- */
async function salvarNome(){
  const nome = $("novoNome").value.trim();
  if(!nome) return alert("Digite o novo nome.");
  try{ const j = await api("/api/nome",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({path:S.projeto, nome})});
    mostrarLog("logId", `✔ nome alterado em ${j.alterados} local(is)`);
    toast("✔ nome alterado", "ok");
  }catch(e){ mostrarLog("logId","[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}
async function salvarVersao(){
  try{ const j = await api("/api/versao",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({path:S.projeto, versionName:$("novaVerName").value.trim(), versionCode:$("novaVerCode").value.trim()})});
    mostrarLog("logId", `✔ versão: ${j.info.versionName} (code ${j.info.versionCode})`);
    toast("✔ versão alterada", "ok");
  }catch(e){ mostrarLog("logId","[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}
async function salvarPacote(){
  const pacote = $("novoPacote").value.trim();
  if(!pacote) return alert("Digite o novo pacote.");
  if(!confirm("Renomear o pacote para:\n"+pacote+"\n\nIsso move as pastas smali e altera todas as referências. Continuar?")) return;
  mostrarLog("logId","Renomeando pacote…\n");
  try{ const j = await api("/api/pacote",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({path:S.projeto, pacote})});
    const r = j.resultado;
    mostrarLog("logId", `✔ pacote: ${r.antigo} → ${r.novo}\n   pastas smali movidas: ${r.smaliDirs}\n   referências smali: ${r.refs}\n   recursos atualizados: ${r.recursos}`);
    toast("✔ pacote renomeado", "ok");
  }catch(e){ addLog("logId","\n[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}

/* ---------------- splash ---------------- */
function renderSplash(){
  const imgs = $("splashImgs"); imgs.innerHTML = "";
  const sp = (S.imagens||[]).filter(i=>i.categoria==="splash").map(i=>i.path);
  const list = sp.length ? sp : (S.splash.imagens||[]);
  if(!list.length) imgs.innerHTML = `<div class="empty">Nenhuma imagem de splash detectada.</div>`;
  list.forEach(p=>{
    const d = thumb(p);
    d.onclick = ()=>{ document.querySelector('.tab[data-tab="visual"]').click(); pedirImagem(p, d); };
    imgs.appendChild(d);
  });
  const xmls = $("splashXml"); xmls.innerHTML = "";
  const xl = (S.splash.layouts||[]);
  if(!xl.length) xmls.innerHTML = `<div class="empty">Nenhum layout de splash detectado.</div>`;
  xl.forEach(p=>{
    const d = el("div","item");
    d.innerHTML = `<div class="u">${esc(p)}</div>`;
    d.onclick = async ()=>{
      document.querySelectorAll("#splashXml .item").forEach(x=>x.classList.remove("sel"));
      d.classList.add("sel"); S.alvoLayout = p; $("layoutSel").textContent = p;
      try{ const j = await api("/api/layout?path="+encodeURIComponent(S.projeto)+"&rel="+encodeURIComponent(p));
           $("layoutEdit").value = j.conteudo; }
      catch(e){ alert(e.message); }
    };
    xmls.appendChild(d);
  });
}
async function salvarLayout(){
  if(!S.alvoLayout) return alert("Selecione um layout.");
  try{ await api("/api/layout",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({path:S.projeto, rel:S.alvoLayout, conteudo:$("layoutEdit").value})});
    mostrarLog("logSplash","✔ layout salvo: "+S.alvoLayout);
    toast("✔ layout salvo", "ok");
  }catch(e){ mostrarLog("logSplash","[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}

/* ---------------- textos ---------------- */
async function carregarStrings(){
  try{ const j = await api("/api/strings?path="+encodeURIComponent(S.projeto));
    S.strings = j.strings; renderStrings(); }
  catch(e){ $("strList").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
function renderStrings(){
  const q = ($("filtroStr").value||"").toLowerCase();
  const list = S.strings.filter(s=>!q || s.nome.toLowerCase().includes(q) || (s.valor||"").toLowerCase().includes(q)).slice(0,300);
  const box = $("strList");
  if(!list.length){ box.innerHTML = `<div class="empty">Nenhum texto.</div>`; return; }
  box.innerHTML = "";
  list.forEach(s=>{
    const d = el("div","item");
    d.innerHTML = `<div class="u"><b style="color:var(--yellow)">${esc(s.nome)}</b><br>${esc(s.valor)}</div>
                   <button class="btn ghost" style="padding:6px 10px;flex:0 0 auto">editar</button>`;
    d.querySelector("button").onclick = async (ev)=>{
      ev.stopPropagation();
      const novo = prompt(`Novo valor para "${s.nome}":`, s.valor);
      if(novo===null) return;
      try{
        const j = await api("/api/substituir",{method:"POST",headers:{"Content-Type":"application/json"},
          body:JSON.stringify({path:S.projeto, regras:[{find:s.valor, replace:novo, caseSensitive:true}]})});
        mostrarLog("logStr", `✔ "${s.valor}" → "${novo}"  (${j.ocorrencias}×)`);
        toast("✔ texto alterado", "ok");
        carregarStrings();
      }catch(e){ mostrarLog("logStr","[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
    };
    box.appendChild(d);
  });
}

/* ---------------- nine-patch / verificação / restaurar ---------------- */
async function recarregarProblemas(){
  try{
    const j = await api("/api/verificar?path="+encodeURIComponent(S.projeto));
    S.ruins = j.ninepatch_ruins||[]; S.problemas = j.problemas||[]; S.avisos = j.avisos||[];
    renderProblemas(); renderLauncher(); renderBackgrounds();
  }catch(e){}
}
async function verificarRecursos(){
  if(!S.projeto) return;
  toast("🔎 Verificando recursos…", "ok");
  await recarregarProblemas();
  if(!S.problemas.length){ toast("✔ Nenhum problema de recurso encontrado.", "ok"); return; }
  toast(`⚠ ${S.problemas.length} problema(s) encontrado(s) — veja o quadro vermelho`, "erro");
  $("listaProblemas").scrollIntoView({behavior:"smooth", block:"center"});
}
async function consertar9(){
  if(!S.ruins.length) await recarregarProblemas();
  if(!S.ruins.length){ toast("✔ Nenhum 9-patch inválido.", "ok"); return; }
  addLog("logBuild","\nConsertando 9-patch…\n");
  try{
    const {job} = await api("/api/ninepatch",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:S.projeto})});
    const res = await acompanhar(job, "logBuild", null);
    addLog("logBuild",`✔ ${res.consertados.length} consertado(s)`+
      (res.falhas.length?` · ${res.falhas.length} falha(s)`:"")+"\n");
    toast(`✔ ${res.consertados.length} 9-patch consertado(s)`, "ok");
    await recarregarProblemas();
  }catch(e){ addLog("logBuild","\n[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}

async function corrigirNomes(){
  addLog("logBuild","\nCorrigindo nomes de recurso inválidos…\n");
  try{
    const {job} = await api("/api/nomes",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:S.projeto})});
    const res = await acompanhar(job, "logBuild", null);
    if(!res.total){ addLog("logBuild","  nenhum nome inválido encontrado\n"); toast("✔ Nenhum nome inválido.", "ok"); return; }
    addLog("logBuild",`✔ ${res.total} recurso(s) renomeado(s) + public.xml atualizado\n`);
    toast(`✔ ${res.total} nome(s) corrigido(s)`, "ok");
    await recarregarProblemas();
  }catch(e){ addLog("logBuild","\n[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}

async function diagnosticar(){
  if(!S.projeto) return;
  $("erroBox").classList.add("hidden");
  addLog("logBuild","\n🔍 Procurando o arquivo que quebra o aapt2…\n");
  try{
    const {job} = await api("/api/diagnostico",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:S.projeto})});
    const res = await acompanhar(job, "logBuild", null);
    if(res.ok){ addLog("logBuild","✔ O aapt2 compilou os recursos sem erro.\n"); toast("✔ recursos OK", "ok"); return; }
    let erros = (res.erros||[]).slice();
    (res.arquivos||[]).forEach(a => erros.unshift("ARQUIVO: " + a.arquivo + (a.erros.length?"  ->  "+a.erros[0]:"")));
    let dica = "Compare as linhas acima com o recurso que você editou por último.";
    const locais = res.local||{};
    if((locais.ninepatch_ruins||[]).length)
      dica = `${locais.ninepatch_ruins.length} arquivo(s) .9.png inválido(s). Toque em <b>Verificar recursos</b> para consertar.`;
    else if((locais.problemas||[]).length)
      dica = `A checagem local achou ${locais.problemas.length} problema(s). Toque em <b>Verificar recursos</b>.`;
    else if((res.arquivos||[]).length)
      dica = "O aapt2 apontou o(s) arquivo(s) marcado(s) com <b>ARQUIVO:</b> acima. Substitua ou restaure esse recurso.";
    mostrarErro({titulo:"Arquivo(s) que o aapt2 recusou", erros, dica});
  }catch(e){ addLog("logBuild","\n[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}

async function restaurar(){
  if(!S.projeto) return;
  if(!confirm("Restaurar o projeto ao original?\n\nTodas as edições feitas neste projeto serão perdidas.\nO APK original NÃO é alterado.")) return;
  addLog("logBuild","\n↺ Restaurando projeto original…\n");
  try{
    const {job} = await api("/api/restaurar",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:S.projeto})});
    await acompanhar(job, "logBuild", (res)=>abrirProjeto(res.project));
    $("erroBox").classList.add("hidden");
    toast("✔ projeto restaurado ao original", "ok");
  }catch(e){ addLog("logBuild","\n[ERRO] "+e.message); toast("✖ "+e.message,"erro"); }
}

/* ---------------- etapa 4 ---------------- */
function mostrarErro({titulo, erros, dica}){
  const box = $("erroBox");
  box.classList.remove("hidden");
  box.innerHTML = `<h3>✖ ${esc(titulo)}</h3>
    ${erros.length?`<ul>${erros.map(e=>`<li>${esc(e)}</li>`).join("")}</ul>`:""}
    ${dica?`<div class="dica">${dica}</div>`:""}`;
  box.scrollIntoView({behavior:"smooth", block:"center"});
}

async function compilar(){
  if(!S.projeto) return;
  const btn = $("btnBuild"); btn.disabled = true; btn.textContent = "⏳ Compilando…";
  $("erroBox").classList.add("hidden");
  $("logBuild").classList.remove("hidden"); $("logBuild").textContent = "Iniciando compilação…\n";
  $("buildResult").classList.add("hidden");
  try{
    const {job} = await api("/api/compilar",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({path:S.projeto, nome:$("nomeSaida").value.trim(),
                           modo:$("modoBuild").value, limpar:$("limparBuild").checked,
                           autoNomes:$("autoNomes").checked})});
    const res = await acompanhar(job, "logBuild", null);
    $("buildResult").classList.remove("hidden");
    $("buildResult").innerHTML = `<h3>✔ APK gerado com sucesso</h3>
      <div class="p">${esc(res.path)}</div>
      <div class="p">Tamanho: ${fmt(res.size)} · modo: ${esc(res.modo)} · assinatura ${res.verified?"verificada":"não verificada"}</div>
      <a class="btn" href="/api/download?file=${encodeURIComponent(res.path)}">⬇ Baixar APK</a>`;
    $("buildResult").scrollIntoView({behavior:"smooth", block:"center"});
    toast("✔ APK compilado e assinado!", "ok");
  }catch(e){
    addLog("logBuild","\n[ERRO] "+e.message+"\n");
    const linhas = (e.message||"").split("\n").filter(l=>l.trim());
    let dica = "Veja o log acima. As linhas com <b>error</b> mostram o arquivo exato do problema. " +
               "Use <b>🔍 Achar o arquivo do erro</b> para localizar sozinho.";
    if(linhas.some(l=>/invalid entry name|invalid resource name/i.test(l)))
      dica = 'Recursos com <b>nome inválido</b> (começando com <code>$</code>, ex: <code>$avd_hide_password__0</code>). ' +
             'Toque em <b>🏷 Corrigir nomes inválidos</b> e compile de novo.';
    if(linhas.some(l=>/public\.xml/i.test(l)))
      dica = 'Erro em <b>res/values/public.xml</b>. Se for "invalid entry name", use <b>🏷 Corrigir nomes inválidos</b>.';
    if(linhas.some(l=>/9-patch|nine|\.9\.png/i.test(l)))
      dica = 'Erro de <b>9-patch</b>. Toque em <b>🩹 Consertar 9-patch</b>, ou use <b>Restaurar original</b>.';
    if(linhas.some(l=>/AndroidManifest|manifest/i.test(l)))
      dica = "Erro no AndroidManifest.xml — provavelmente veio de uma edição de pacote/nome. Use <b>Restaurar original</b> e refaça.";
    mostrarErro({titulo:"Falha ao compilar", erros:linhas.slice(0,12), dica});
    toast("✖ falhou — veja o quadro vermelho", "erro");
  }
  btn.disabled = false; btn.textContent = "🚀 COMPILAR APK EDITADO";
}

/* ---------------- boot ---------------- */
carregarStatus();
carregarApks();
