#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
APK Editor Pro - Servidor Flask (interface web)
Rode no Termux:  python3 app.py   e abra http://127.0.0.1:5000
"""

import os
import traceback

from flask import Flask, request, jsonify, render_template, send_file

import engine as E

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 512 * 1024 * 1024  # 512 MB por upload


def ok(**kw):
    d = {"ok": True}
    d.update(kw)
    return jsonify(d)


def fail(msg, code=400):
    return jsonify({"ok": False, "erro": str(msg)}), code


@app.errorhandler(Exception)
def on_error(e):
    code = 400 if isinstance(e, (ValueError, FileNotFoundError)) else 500
    return jsonify({"ok": False, "erro": str(e),
                    "trace": traceback.format_exc()[-1200:]}), code


@app.route("/")
def index():
    return render_template("index.html")


# ------------------------------------------------------------------- api ----
@app.route("/api/instalar", methods=["POST"])
def api_instalar():
    """Instala as ferramentas que faltam (pacotes do Termux + reservas portateis)."""
    d = request.get_json(silent=True) or {}
    tentar_repos = bool(d.get("repos", True))
    jid = E.JOBS.start("instalar",
                       lambda log: E.instalar_ferramentas(log=log, tentar_repos=tentar_repos))
    return ok(job=jid)


@app.route("/api/status")
def api_status():
    E.ensure_dirs()
    return ok(tools=E.tools_status(), apk_dir=E.APK_DIR, work_dir=E.WORK_DIR,
              output_dir=E.OUTPUT_DIR, apk_dir_exists=os.path.isdir(E.APK_DIR))


@app.route("/api/apks")
def api_apks():
    return ok(apks=E.list_apks())


@app.route("/api/projetos")
def api_projetos():
    return ok(projetos=E.list_projects())


@app.route("/api/info")
def api_info():
    apk = request.args.get("apk", "")
    if not apk:
        return fail("Informe o APK.")
    if not os.path.isfile(apk):
        return fail("APK nao encontrado: " + apk)
    return ok(info=E.apk_info(apk))


@app.route("/api/decompilar", methods=["POST"])
def api_decompilar():
    d = request.get_json(force=True)
    apk = d.get("apk")
    if not apk or not os.path.isfile(apk):
        return fail("APK invalido.")
    jid = E.JOBS.start("decompilar",
                       lambda log: {"project": E.decompile(apk, log=log)})
    return ok(job=jid)


@app.route("/api/job/<jid>")
def api_job(jid):
    since = int(request.args.get("since", 0))
    j = E.JOBS.get(jid, since)
    if not j:
        return fail("Tarefa nao encontrada.", 404)
    return ok(job=j)


@app.route("/api/projeto")
def api_projeto():
    p = request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    ver = E.verificar_recursos(p)
    return ok(info=E.project_info(p),
              launcher=E.guess_launcher_icon(p),
              backgrounds=E.guess_backgrounds(p),
              splash=E.guess_splash(p),
              ninepatch_ruins=ver["ninepatch_ruins"],
              problemas=ver["problemas"],
              avisos=ver["avisos"])


@app.route("/api/verificar", methods=["GET", "POST"])
def api_verificar():
    """Checagem local rapida dos recursos (sem aapt2)."""
    p = (request.get_json(silent=True) or {}).get("path") if request.method == "POST" \
        else request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(**E.verificar_recursos(p))


@app.route("/api/preview")
def api_preview():
    """Serve a imagem real do projeto para o painel mostrar a miniatura."""
    p = request.args.get("path", "")
    rel = request.args.get("rel", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    try:
        full = E.preview_path(p, rel)
    except (ValueError, FileNotFoundError) as e:
        return fail(str(e), 404)
    ext = os.path.splitext(full)[1].lower()
    return send_file(full, mimetype=E.MIME.get(ext, "application/octet-stream"),
                     max_age=0)


@app.route("/api/servidores")
def api_servidores():
    p = request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(servidores=E.scan_servers(p))


@app.route("/api/buscar-endereco")
def api_buscar_endereco():
    """Busca servidor/endereco no projeto (estilo APK Editor)."""
    p = request.args.get("path", "")
    termo = request.args.get("q", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(**E.buscar_enderecos(p, termo))


@app.route("/api/gradientes")
def api_gradientes():
    p = request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(gradientes=E.list_gradients(p))


@app.route("/api/gradiente", methods=["POST"])
def api_gradiente():
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    r = E.set_gradient(p, d.get("arquivo", ""), index=d.get("index", 0),
                       start=d.get("start"), end=d.get("end"),
                       center=d.get("center"), angle=d.get("angle"),
                       tipo=d.get("tipo"))
    return ok(resultado=r)


@app.route("/api/urls")
def api_urls():
    p = request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(urls=E.scan_urls(p))


@app.route("/api/buscar")
def api_buscar():
    p = request.args.get("path", "")
    term = request.args.get("q", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    if not term:
        return fail("Digite algo para buscar.")
    return ok(resultados=E.search_text(p, term))


@app.route("/api/substituir", methods=["POST"])
def api_substituir():
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    regras = d.get("regras") or []
    if not regras:
        return fail("Nenhuma regra de substituicao informada.")
    total_f = total_o = 0
    detalhes = []
    for r in regras:
        f, o = E.replace_text(p, r.get("find", ""), r.get("replace", ""),
                              case_sensitive=r.get("caseSensitive", True))
        total_f += f
        total_o += o
        detalhes.append({"find": r.get("find"), "replace": r.get("replace"),
                         "arquivos": f, "ocorrencias": o})
    return ok(arquivos=total_f, ocorrencias=total_o, detalhes=detalhes)


@app.route("/api/imagens")
def api_imagens():
    p = request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    imgs = E.list_images(p)
    return ok(imagens=imgs, categorias=E.contar_categorias(imgs))


@app.route("/api/cores")
def api_cores():
    p = request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(**E.list_colors(p))


@app.route("/api/cor", methods=["POST"])
def api_cor():
    """Altera uma cor nomeada (colors.xml) e opcionalmente o valor antigo em todo o res."""
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    nome = (d.get("nome") or "").strip()
    nova = d.get("nova") or ""
    if not nome:
        return fail("Informe o nome da cor.")
    return ok(resultado=E.definir_cor_nomeada(
        p, nome, nova, global_=bool(d.get("global", True))))


@app.route("/api/cor-valor", methods=["POST"])
def api_cor_valor():
    """Troca um valor hex por outro em todos os XMLs de res/."""
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(resultado=E.substituir_cor(p, d.get("antiga", ""), d.get("nova", "")))


@app.route("/api/fontes")
def api_fontes():
    p = request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(fontes=E.list_fonts(p))


@app.route("/api/strings")
def api_strings():
    p = request.args.get("path", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(strings=E.list_app_strings(p))


@app.route("/api/upload", methods=["POST"])
def api_upload():
    p = request.form.get("path", "")
    target = request.form.get("target", "")
    broad = request.form.get("broad", "")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    if "file" not in request.files:
        return fail("Nenhum arquivo enviado.")
    data = request.files["file"].read()
    if not data:
        return fail("Arquivo vazio.")
    logs = []
    if broad:
        n, files, avisos = E.replace_resource_broad(p, broad, data, log=logs.append)
        if n == 0:
            return fail("Nenhuma variante de '%s' encontrada no projeto." % broad)
        return ok(substituidos=files, quantidade=n, avisos=avisos, log=logs)
    if not target:
        return fail("Informe o arquivo de destino.")
    rel, avisos = E.replace_resource(p, target, data, log=logs.append)
    return ok(substituido=rel, avisos=avisos, log=logs)


@app.route("/api/nomes", methods=["GET", "POST"])
def api_nomes():
    """GET lista recursos com nome invalido; POST corrige (renomeia + public.xml)."""
    if request.method == "GET":
        p = request.args.get("path", "")
        if not os.path.isdir(p):
            return fail("Projeto nao encontrado.")
        return ok(invalidos=E.achar_nomes_invalidos(p))
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    jid = E.JOBS.start("nomes", lambda log: E.corrigir_nomes_invalidos(p, log=log))
    return ok(job=jid)


@app.route("/api/ninepatch", methods=["GET", "POST"])
def api_ninepatch():
    if request.method == "GET":
        p = request.args.get("path", "")
        if not os.path.isdir(p):
            return fail("Projeto nao encontrado.")
        return ok(ruins=E.find_broken_ninepatch(p))
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    jid = E.JOBS.start("ninepatch", lambda log: E.repair_ninepatches(p, log=log))
    return ok(job=jid)


@app.route("/api/nome", methods=["POST"])
def api_nome():
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    n = E.set_app_name(p, d.get("nome", "").strip())
    if not n:
        return fail("Nenhum app_name encontrado para alterar.")
    return ok(alterados=n)


@app.route("/api/pacote", methods=["POST"])
def api_pacote():
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    return ok(resultado=E.rename_package(p, d.get("pacote", "").strip()))


@app.route("/api/versao", methods=["POST"])
def api_versao():
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    E.set_version(p, d.get("versionName"), d.get("versionCode"))
    return ok(info=E.project_info(p))


@app.route("/api/layout", methods=["GET", "POST"])
def api_layout():
    if request.method == "GET":
        p = request.args.get("path", "")
        rel = request.args.get("rel", "")
        if not os.path.isdir(p):
            return fail("Projeto nao encontrado.")
        return ok(rel=rel, conteudo=E.read_layout(p, rel))
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    E.write_layout(p, d.get("rel", ""), d.get("conteudo", ""))
    return ok()


@app.route("/api/compilar", methods=["POST"])
def api_compilar():
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    nome = d.get("nome") or (os.path.basename(p) + "-editado.apk")
    modo = d.get("modo") or "auto"
    limpar = bool(d.get("limpar", True))
    auto_nomes = bool(d.get("autoNomes", True))
    jid = E.JOBS.start("compilar",
                       lambda log: E.build(p, out_name=nome, log=log,
                                           modo=modo, limpar=limpar,
                                           auto_nomes=auto_nomes))
    return ok(job=jid)


@app.route("/api/diagnostico", methods=["POST"])
def api_diagnostico():
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    jid = E.JOBS.start("diagnostico", lambda log: E.diagnosticar_recursos(p, log=log))
    return ok(job=jid)


@app.route("/api/restaurar", methods=["POST"])
def api_restaurar():
    """Volta o projeto ao estado original (decompila o APK de novo)."""
    d = request.get_json(force=True)
    p = d.get("path")
    if not os.path.isdir(p):
        return fail("Projeto nao encontrado.")
    meta = E.read_meta(p)
    apk = meta.get("apk")
    if not apk or not os.path.isfile(apk):
        return fail("Nao encontrei o APK original deste projeto. "
                    "Selecione o APK na biblioteca e decompile novamente.")
    jid = E.JOBS.start("restaurar", lambda log: {"project": E.decompile(apk, log=log)})
    return ok(job=jid)


@app.route("/api/download")
def api_download():
    f = request.args.get("file", "")
    real = os.path.abspath(f)
    if not os.path.isfile(real):
        return fail("Arquivo nao encontrado.", 404)
    if not real.startswith(os.path.abspath(E.OUTPUT_DIR)) and \
       not real.startswith(os.path.abspath(E.APK_DIR)):
        return fail("Acesso negado.", 403)
    return send_file(real, as_attachment=True, download_name=os.path.basename(real))


if __name__ == "__main__":
    E.ensure_dirs()
    t = E.tools_status()
    print("=" * 60)
    print("  APK EDITOR PRO  -  interface web")
    print("  Pasta de APKs :", E.APK_DIR)
    print("  Saida         :", E.OUTPUT_DIR)
    print("  Ferramentas   :", "OK" if t["ok"] else ("FALTANDO: " + ", ".join(t["missing"])))
    print("  Pillow        :", "OK" if t["pillow"] else "ausente (pkg install python-pillow -y)")
    print("  Abra no navegador: http://127.0.0.1:5000")
    print("=" * 60)
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
