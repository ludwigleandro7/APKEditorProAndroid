# APK Editor Pro

Editor profissional de APK para Android, rodando no **Termux** com interface web.
Decompila, edita e recompila APKs assinados — servidores, logo, fundo, fontes,
splash, nome, pacote e versão.

Feito para o João. Identidade visual: verde neon / amarelo / preto.

---

## 1. Instalação (Termux)

```bash
pkg install unzip -y
termux-setup-storage        # toque em PERMITIR
cd /sdcard/Download
unzip -o apkeditor-pro.zip
cp -r apkeditor-pro ~/
cd ~/apkeditor-pro
bash install.sh
```

> **Importante:** nunca rode o `install.sh` de dentro de `/sdcard` — essa pasta é
> montada como `noexec` no Android. Por isso o passo `cp -r apkeditor-pro ~/`.

O instalador agora **instala tudo sozinho e se vira quando falta algo**:

1. habilita o repositório **`x11`** (é de onde vêm `apktool` e `apksigner` no Termux);
2. instala **um pacote por vez** — se um falhar, os outros continuam;
3. se `apktool` ou `apksigner` não existirem no repositório, **baixa a versão portátil**:
   - `apktool.jar` oficial (só precisa do Java) + atalho criado sozinho;
   - `uber-apk-signer.jar` como assinador de reserva (o app detecta e usa sozinho);
4. no fim imprime um **relatório** com ✓/✕ de cada ferramenta.

### Se ainda faltar alguma ferramenta

O painel detecta e mostra um **card amarelo “⚠ Ferramentas faltando”** logo no topo,
com um botão **⬇ Instalar ferramentas automaticamente**. Ele faz tudo de novo de dentro
do próprio app — você não precisa mexer no terminal.

Se preferir na mão:

```bash
pkg install -y x11-repo
pkg update -y
pkg install -y openjdk-17 apktool apksigner zipalign aapt aapt2 python python-pillow
pip install flask
```

## 2. Uso

```bash
apkeditor
```

Depois abra no navegador do celular: **http://127.0.0.1:5000**

Alternativa sem instalar o atalho:

```bash
cd ~/apkeditor-pro && python3 app.py
```

Coloque seus APKs em `/storage/emulated/0/ApkEditor`.
Os APKs editados saem em `/storage/emulated/0/ApkEditor/Editados`.

---

## 3. Fluxo de trabalho

| Etapa | O que faz |
|---|---|
| **1 · Biblioteca** | Lista todos os `.apk` da pasta. Toque para selecionar. |
| **2 · Análise** | Mostra pacote, nome, versão, Android mín/alvo e ícone. Botão **Decompilar** roda o `apktool d`. |
| **3 · Painel** | Seis abas de edição (abaixo). |
| **4 · Compilar** | `apktool b` → `zipalign` → `apksigner` → APK assinado e pronto para instalar. |

### Abas do painel

- **🌐 Servidores** — duas formas de trocar:
  - **🔍 Buscar e trocar** — cole ou digite o endereço (ex: `http://auth.urlsync.gy:80`),
    toque em **Buscar** e ele mostra **quantas vezes aparece** e em quantos arquivos.
    Escolha o resultado, digite o novo endereço e toque em **⇄ Trocar tudo**.
  - **Lista de servidores** — todos os servidores já **agrupados**: uma linha por servidor,
    com quantos endereços e ocorrências. Toque num para trocar tudo dele, sem tocar
    em nenhum outro.
  - **Endereços individuais (avançado)** — troca **só um endereço** específico.
- **🖼 Imagens** — **galeria completa com todas as imagens do app**, cada uma com prévia
  de verdade, dimensões e um **rótulo colorido** dizendo o que ela é:

  | Rótulo | Significa |
  |---|---|
  | 🟢 `ÍCONE` | ícone do app na tela inicial |
  | 🟡 `LOGO` | logotipo / marca |
  | 🔵 `FUNDO` | imagem de fundo das telas (por nome *ou* por tamanho ≥ 400px) |
  | 🟠 `BANNER` | banner / capa / destaque |
  | 🟣 `SPLASH` | tela de abertura |
  | 🟩 `BOTÃO` | imagem de botão |

  Seções: ⭐ ícone · 🌄 fundos · 🚀 splash · 🗂 todas (com filtro por texto e categoria).
  **Toque em qualquer imagem** → o seletor abre → trocou.
- **🎨 Cores** — muda as cores do aplicativo:
  - **Cores do tema** — as de `res/values/colors.xml`, com contagem de usos.
  - **Atributos do tema** — `colorPrimary`, `colorAccent`, `android:windowBackground`…
    cada um com **explicação em português** (ex: *colorPrimary = barra de título*).
  - **Valores usados** — todas as cores escritas direto nos arquivos, com contagem.
  - **🌈 Gradientes** — lista os gradientes do app (fundos, botões) e permite trocar
    **cor inicial**, **cor final**, **ângulo** e **tipo** (linear/radial/sweep),
    com **24 gradientes prontos** (Neon, Sunset, Oceano, Roxo, Fogo…).

  No seletor de cor você tem: **paleta Material Design completa** (19 cores × 14 tons),
  **paleta rápida** (589 tons), seletor nativo, campo hex e a opção
  **“aplicar em todos os lugares que usam essa cor”**.
- **🔤 Fontes** — lista `.ttf/.otf/.ttc` embutidos. **Toque na fonte** e o seletor
  abre: escolha o arquivo e substitui na hora.
- **📦 Nome / Pacote** — troca o nome do app (todas as traduções `strings.xml`),
  a versão (`versionName`/`versionCode`) e o **pacote** (renomeia pastas smali e
  todas as referências — permite instalar ao lado do original).
- **🚀 Splash / Intro** — imagens e layouts de abertura detectados; editor de XML.
- **📝 Textos** — todas as strings do `res/values/strings.xml` com botão de editar.

---

## 4. Compilação — modos e correção de erros

### Verificação automática de recursos

Ao abrir um projeto, o painel faz uma **checagem local** (sem aapt2) e mostra um
quadro vermelho se achar algo que comprovadamente quebra o build:

- **nome de recurso inválido** — o aapt2 recusa nomes que não começam com letra ou `_`
  (caso clássico: `$avd_hide_password__0`, vindo dos *inline resources* do Android Studio);
- arquivo **vazio** (0 bytes);
- arquivo com extensão `.png/.jpg/.webp/.gif` mas **conteúdo de outro formato**;
- **`.9.png` inválido** (borda de 1px que não é transparente nem preta).

O botão **🔎 Verificar recursos** refaz a checagem a qualquer momento.

### 🏷 Nomes inválidos (`$avd_…`) — a causa nº 1 de erro no aapt2

APKs montados com Android Studio recente trazem recursos internos de
**Animated Vector Drawable** com nome começando por `$`. O aapt2 aborta com:

```
error: resource 'drawable/$avd_hide_password__0' has invalid entry name '$avd_hide_password__0'.
error: .../res/values/public.xml: error: file failed to compile.
```

**O botão COMPILAR já corrige isso sozinho.** Antes de recompilar, o editor:

1. renomeia o arquivo (`$avd_hide_password__0.xml` → `avd_hide_password__0.xml`);
2. atualiza `res/values/public.xml` **mantendo o mesmo ID** de recurso;
3. atualiza todas as referências (`@drawable/…`) nos XMLs do projeto.

Como o ID é preservado, nada quebra no app. Para desligar, desmarque a opção
*“corrigir automaticamente nomes de recurso inválidos”* na etapa 4 — ou use o
botão **🏷 Corrigir nomes inválidos** manualmente.

### Modos de compilação

Na etapa 4 você escolhe o modo. **Automático** é o recomendado: ele tenta, em
sequência, até um funcionar:

1. padrão → 2. `--no-crunch` (não otimiza PNGs) → 3. `--use-aapt2`

O log mostra qual modo funcionou (`✔ recompilado com sucesso (modo ...)`).

> O modo *aapt v1* (`--aapt`) foi removido: apktool 3.x não suporta mais
> (`Legacy aapt is no longer supported`).

### 🔍 Achar o arquivo do erro

O botão **🔍 Achar o arquivo do erro (aapt2)** roda o `aapt2` de verdade e, se ele
recusar os recursos, **isola o arquivo exato** em três passos:

1. compila `res/` inteiro;
2. se falhar, compila cada subpasta de `res/`;
3. na subpasta que falha, compila **arquivo por arquivo**.

No fim ele mostra a linha `ARQUIVO: res/drawable/xxx.png` com o erro cru do aapt2.

### 🩹 9-patch (`.9.png`) — entenda de uma vez

Existem **duas formas** de nine-patch (fonte: apktool.org):

| Forma | Como é |
|---|---|
| **compiled** (dentro do APK) | sem borda visível; os dados ficam no chunk binário `npTc` |
| **source** (depois do `apktool d`) | **com borda de 1px**; **sem** `npTc` |

O apktool converte automaticamente para **source** ao decompilar. Então um `.9.png`
**saudável no projeto NÃO tem `npTc`** — ele tem a borda.

A regra da borda: cada pixel da moldura de 1px precisa ser **totalmente
transparente** ou **preto sólido** (`#000000`, alfa 255). Qualquer outra cor ou
alfa faz o `aapt2` recusar com:

```
error: 9-patch image must have a 1-pixel transparent border.
```

**Esta versão resolve isso sozinha:**

- Ao substituir qualquer `.9.png`, a imagem é **ajustada automaticamente** — se ela
  não tiver a borda correta, é embrulhada numa borda transparente de 1px.
- O painel **detecta** `.9.png` inválidos e mostra o quadro vermelho com o botão
  **Consertar 9-patch agora**.
- Arquivos `.9.png` **saudáveis nunca são tocados** pelo conserto.

### ↺ Restaurar original

O botão **Restaurar original** (etapa 4) decompila o APK de novo, descartando
todas as edições do projeto. Use quando uma edição der errado e você quiser
começar limpo. O APK original nunca é alterado.

---

## 5. Estrutura do projeto

```
apkeditor-pro/
├── app.py              API Flask + rotas
├── engine.py           motor: apktool, edição, nine-patch, assinatura, jobs
├── templates/
│   └── index.html      painel (4 etapas, 6 abas)
├── static/
│   ├── logo.png        logo João APK
│   ├── favicon.png
│   ├── style.css       tema verde neon / amarelo / preto
│   └── app.js          lógica do painel
├── install.sh          instalador Termux
├── requirements.txt
└── README.md
```

Pastas criadas em tempo de execução:

```
~/apkeditor_work/projetos/   projetos decompilados
~/apkeditor_work/keystore/   chave de assinatura (gerada automaticamente)
/storage/emulated/0/ApkEditor/Editados/   APKs finais
```

Variáveis de ambiente opcionais:

```bash
export APKEDITOR_DIR=/storage/emulated/0/ApkEditor   # pasta dos APKs
export APKEDITOR_WORK=~/apkeditor_work               # pasta de trabalho
```

---

## 6. Limites e avisos

- **Assinatura de debug.** O APK gerado é assinado com uma chave de debug criada
  na primeira compilação. Serve para instalar no aparelho e nos aparelhos dos
  clientes. Publicar na Play Store exigiria uma chave de release própria.
- **APK assinado ≠ APK original atualizável.** Ao trocar o pacote, o app editado
  instala ao lado do original. Sem trocar o pacote, é preciso desinstalar o
  original antes (assinatura diferente).
- **A conversão de 9-patch embrulha a imagem** numa borda transparente de 1px e
  mantém o miolo inteiro esticável. Se o arquivo original tiver cantos fixos que
  precisam ser preservados, envie um `.9.png` já pronto (com a borda correta) —
  nesse caso ele é usado exatamente como veio.
- **Não recompila tudo.** Alguns APKs protegidos/ofuscados ou com recursos
  proprietários podem falhar no `apktool b`. O log mostra o erro exato.
- **Use apenas em APKs que você tem o direito de modificar.**

---

## 7. Solução de problemas

| Problema | Causa / solução |
|---|---|
| `java: command not found` | `pkg install openjdk-17 -y` |
| `apktool: command not found` | `pkg install apktool -y` |
| `apktool: command not found` | `pkg install x11-repo && pkg update && pkg install apktool` — ou use o botão **⬇ Instalar ferramentas** |
| `apksigner` faltando | `pkg install x11-repo && pkg install apksigner` — ou o botão **⬇ Instalar ferramentas** |
| `zipalign`/`keytool` faltando | `pkg install zipalign` / vem com `openjdk-17` |
| Nada instala, tudo falha | Rode `pkg update -y` e tente de novo; verifique a internet |
| `python3: not found` | `pkg install python -y` |
| Conversão 9-patch desligada | `pkg install python-pillow -y` |
| Pasta de APKs não existe | Crie `/storage/emulated/0/ApkEditor` ou rode `termux-setup-storage` |
| `ModuleNotFoundError: flask` | `pip install flask` |
| Quero trocar um servidor | Aba **🌐 Servidores** → **🔍 Buscar e trocar** → digite e busque |
| Quero mudar as cores do app | Aba **🎨 Cores** → toque na cor → escolha na paleta → **Aplicar cor** |
| Quero mudar um gradiente | Aba **🎨 Cores** → seção **🌈 Gradientes** → toque → escolha cores/ângulo |
| Erro `invalid entry name` / `public.xml` | O botão **COMPILAR** já corrige sozinho, ou use **🏷 Corrigir nomes inválidos** |
| Erro `Legacy aapt is no longer supported` | Normal — apktool 3.x não tem mais aapt1. Deixe em **Automático** |
| Não sei qual arquivo quebra | Toque em **🔍 Achar o arquivo do erro (aapt2)** — ele isola o arquivo exato |
| Erro `--no-crunch` resolveu | Normal: alguns APKs têm PNGs que o otimizador rejeita. Deixe em **Automático** |
| Erro em `AndroidManifest.xml` | Use **Restaurar original** e refaça as edições |
| APK não instala | Desinstale o app original, ou renomeie o pacote na aba **Nome / Pacote** |
