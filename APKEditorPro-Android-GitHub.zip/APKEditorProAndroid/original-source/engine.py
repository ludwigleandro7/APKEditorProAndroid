#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
APK Editor Pro - Motor de edicao
Decompila, edita recursos/smali e recompila APKs assinados.

Autor: SuperAgent / CREAO  -  para Joao
Requer (Termux): openjdk-17 apktool apksigner zipalign aapt python python-pillow
"""

import os
import re
import io
import json
import shutil
import struct
import subprocess
import tempfile
import threading
import time
import zlib
from urllib.parse import urlsplit

HOME = os.path.expanduser("~")

# ----------------------------------------------------------------------------
# Configuracao de caminhos
# ----------------------------------------------------------------------------
APK_DIR = os.environ.get("APKEDITOR_DIR", "/storage/emulated/0/ApkEditor")
WORK_DIR = os.environ.get("APKEDITOR_WORK", os.path.join(HOME, "apkeditor_work"))
PROJECTS_DIR = os.path.join(WORK_DIR, "projetos")
OUTPUT_DIR = os.path.join(APK_DIR, "Editados")
KEYSTORE_DIR = os.path.join(WORK_DIR, "keystore")
KEYSTORE = os.path.join(KEYSTORE_DIR, "debug.keystore")
KS_PASS = "android"
KS_ALIAS = "apkeditor"

# ferramentas portateis (reserva, caso o repositorio nao tenha o pacote)
TOOLS_DIR = os.path.join(HOME, ".apkeditor", "tools")
APKTOOL_JAR = os.path.join(TOOLS_DIR, "apktool.jar")
UBER_JAR = os.path.join(TOOLS_DIR, "uber-apk-signer.jar")
APKTOOL_URL = ("https://github.com/iBotPeaches/Apktool/releases/download/"
               "v2.11.1/apktool_2.11.1.jar")
UBER_URL = ("https://github.com/patrickfav/uber-apk-signer/releases/download/"
            "v1.3.0/uber-apk-signer-1.3.0.jar")

PKGS_TERMUX = ["python", "python-pillow", "openjdk-17", "zipalign",
               "aapt", "aapt2", "apksigner", "apktool"]

TEXT_EXT = {
    ".smali", ".xml", ".json", ".js", ".txt", ".properties", ".html", ".htm",
    ".css", ".cfg", ".ini", ".csv", ".yml", ".yaml", ".md", ".svg", ".ts",
    ".mjs", ".kt", ".java", ".gradle", ".pro", ".data", ".plist", ".strings",
}
IMG_EXT = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}
FONT_EXT = {".ttf", ".otf", ".ttc", ".woff", ".woff2"}
MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp",
        ".ttf": "font/ttf", ".otf": "font/otf", ".ttc": "font/collection",
        ".woff": "font/woff", ".woff2": "font/woff2", ".svg": "image/svg+xml"}

URL_RE = re.compile(rb"https?://[^\s\"'<>()\[\]\\{}|^`]+", re.I)


# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------
def ensure_dirs():
    for d in (APK_DIR, WORK_DIR, PROJECTS_DIR, OUTPUT_DIR, KEYSTORE_DIR):
        try:
            os.makedirs(d, exist_ok=True)
        except Exception:
            pass


def which(name):
    return shutil.which(name)


def has_pillow():
    try:
        import PIL  # noqa
        return True
    except Exception:
        return False


def _pkg_bin():
    """Caminho do 'pkg' do Termux (mesmo fora do PATH)."""
    p = which("pkg")
    if p:
        return p
    for c in ("/data/data/com.termux/files/usr/bin/pkg",
              os.path.join(os.environ.get("PREFIX", ""), "bin", "pkg")):
        if c and os.path.isfile(c):
            return c
    return None


def assinador_disponivel():
    """apksigner | uber | jarsigner | None"""
    if which("apksigner"):
        return "apksigner"
    if os.path.isfile(UBER_JAR):
        return "uber"
    if which("jarsigner"):
        return "jarsigner"
    return None


def tools_status():
    need = ["java", "apktool", "zipalign", "keytool"]
    st = {n: bool(which(n)) for n in need}
    st["aapt"] = bool(which("aapt"))
    st["aapt2"] = bool(which("aapt2"))
    st["pillow"] = has_pillow()
    st["apksigner"] = bool(which("apksigner"))
    st["assinador"] = assinador_disponivel()
    st["uberJar"] = os.path.isfile(UBER_JAR)
    st["apktoolJar"] = os.path.isfile(APKTOOL_JAR)
    # assinar tambem e obrigatorio
    st["ok"] = all(st[n] for n in need) and st["assinador"] is not None
    st["missing"] = [n for n in need if not st[n]]
    if st["assinador"] is None:
        st["missing"].append("apksigner")
    return st


def instalar_ferramentas(log=None, tentar_repos=True):
    """
    Instala tudo o que falta: pacotes do Termux, Flask e as reservas portateis.
    Feito para rodar de dentro do proprio painel.
    """
    rel = {"pacotes": [], "reservas": [], "avisos": []}
    pkg = _pkg_bin()
    if not pkg:
        rel["avisos"].append("comando 'pkg' nao encontrado (isso nao e Termux?)")

    if tentar_repos and pkg:
        if log:
            log("→ habilitando repositorio x11 (onde ficam apktool/apksigner)...")
        run([pkg, "install", "-y", "x11-repo"], log=log)
        run([pkg, "update", "-y"], log=log)

    for p in PKGS_TERMUX:
        if log:
            log("→ instalando %s ..." % p)
        rc, _ = run([pkg, "install", "-y", p], log=log) if pkg else (1, "")
        rel["pacotes"].append({"pacote": p, "ok": rc == 0})
        if rc != 0 and log:
            log("  [aviso] %s nao esta disponivel no repositorio" % p)

    # Flask
    if not _tem_modulo("flask"):
        if log:
            log("→ instalando Flask...")
        run(["python3", "-m", "pip", "install", "flask"], log=log)

    # reservas portateis
    os.makedirs(TOOLS_DIR, exist_ok=True)
    if not which("apktool"):
        if log:
            log("→ apktool nao veio do repositorio — baixando o JAR oficial...")
        if _baixar(APKTOOL_URL, APKTOOL_JAR, log):
            _criar_wrapper_apktool(log)
            rel["reservas"].append("apktool.jar")
    if not which("apksigner") and not os.path.isfile(UBER_JAR):
        if log:
            log("→ apksigner nao veio do repositorio — baixando assinador portatil...")
        if _baixar(UBER_URL, UBER_JAR, log):
            rel["reservas"].append("uber-apk-signer.jar")
    rel["status"] = tools_status()
    return rel


def _tem_modulo(nome):
    try:
        __import__(nome)
        return True
    except Exception:
        return False


def _baixar(url, destino, log=None):
    os.makedirs(os.path.dirname(destino), exist_ok=True)
    if which("curl"):
        rc, _ = run(["curl", "-fsSL", "--retry", "2", "-o", destino, url], log=log)
    elif which("wget"):
        rc, _ = run(["wget", "-q", "-O", destino, url], log=log)
    else:
        if log:
            log("  [erro] preciso do curl ou wget para baixar")
        return False
    if rc == 0 and os.path.isfile(destino) and os.path.getsize(destino) > 100000:
        return True
    if log:
        log("  [erro] download falhou (verifique a internet)")
    return False


def _criar_wrapper_apktool(log=None):
    prefix = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
    wrapper = os.path.join(prefix, "bin", "apktool")
    try:
        with open(wrapper, "w") as f:
            f.write('#!%s/bin/bash\nexec java -jar "%s" "$@"\n' % (prefix, APKTOOL_JAR))
        os.chmod(wrapper, 0o755)
        if log:
            log("  ✓ apktool instalado via JAR (so precisa do Java)")
        return True
    except OSError as e:
        if log:
            log("  [erro] nao consegui criar o atalho apktool: %s" % e)
        return False


def run(cmd, cwd=None, log=None, timeout=None):
    """Executa um comando e transmite a saida linha a linha."""
    if log:
        log("$ " + " ".join(cmd))
    try:
        p = subprocess.Popen(
            cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1, errors="replace",
        )
    except FileNotFoundError as e:
        msg = "Comando nao encontrado: %s (%s)" % (cmd[0], e)
        if log:
            log("[ERRO] " + msg)
        return 127, msg

    out = []
    start = time.time()
    for line in p.stdout:
        out.append(line)
        if log:
            log(line.rstrip("\n"))
        if timeout and (time.time() - start) > timeout:
            p.kill()
            if log:
                log("[ERRO] Tempo limite excedido.")
            break
    p.wait()
    return p.returncode, "".join(out)


def extrair_erros(texto, limite=14):
    """Separa as linhas de erro reais do monte de stacktrace do apktool."""
    chaves = ("error", "erro", "failed", "failure", "cannot", "can't",
              "invalid", "unable", "no such", "not found", "exception",
              "corrupt", "malformed", "requires", "missing")
    linhas, vistos = [], set()
    for bruta in texto.splitlines():
        s = bruta.strip()
        if not s or len(s) > 400:
            continue
        low = s.lower()
        # pula stacktrace do apktool/java
        if low.startswith("at ") or low.startswith("caused by:") or s.startswith("..."):
            continue
        if "brut." in s or "java." in s:
            continue
        if not any(k in low for k in chaves):
            continue
        if s in vistos:
            continue
        vistos.add(s)
        linhas.append(s)
        if len(linhas) >= limite:
            break
    return linhas


# ----------------------------------------------------------------------------
# Nine-patch (9.png) - deteccao, criacao e reparo
#
# IMPORTANTE (apktool.org/wiki/in-depth/9patch-images):
#   - forma "compiled" (dentro do APK): SEM borda visivel, dados no chunk npTc
#   - forma "source"   (apos apktool d): COM borda de 1px, SEM npTc
#   O apktool converte compiled -> source automaticamente ao decompilar.
#   Portanto um .9.png SAUDAVEL no projeto NAO tem npTc: ele tem a borda.
#   A borda de 1px so pode ser TRANSPARENTE ou PRETA SOLIDA (0,0,0,255).
#   Qualquer outra cor/alfa => o aapt2 recusa a compilar.
# ----------------------------------------------------------------------------
PNG_SIG = b"\x89PNG\r\n\x1a\n"


def _png_chunks(data):
    if data[:8] != PNG_SIG:
        raise ValueError("nao e um arquivo PNG")
    pos, out = 8, []
    while pos + 8 <= len(data):
        ln = struct.unpack(">I", data[pos:pos + 4])[0]
        typ = data[pos + 4:pos + 8]
        end = pos + 12 + ln
        if end > len(data):
            break
        out.append((typ, data[pos:end]))
        pos = end
        if typ == b"IEND":
            break
    return out


def png_has_ninepatch(data):
    """True se o PNG esta na forma COMPILADA (tem o chunk npTc)."""
    try:
        return any(t == b"npTc" for t, _ in _png_chunks(data))
    except Exception:
        return False


def _pil():
    try:
        from PIL import Image
        return Image
    except Exception:
        raise RuntimeError(
            "Preciso do Pillow para validar/consertar 9-patch.\n"
            "Rode no Termux:  pkg install python-pillow -y")


def _border_ok(im):
    """A borda de 1px de um 9-patch fonte precisa ser transparente ou preta."""
    w, h = im.size
    if w < 3 or h < 3:
        return False
    px = im.load()

    def valido(p):
        r, g, b, a = p[0], p[1], p[2], p[3]
        return a == 0 or (r == 0 and g == 0 and b == 0 and a == 255)

    for x in range(w):
        if not valido(px[x, 0]) or not valido(px[x, h - 1]):
            return False
    for y in range(h):
        if not valido(px[0, y]) or not valido(px[w - 1, y]):
            return False
    return True


def ninepatch_status(path):
    """compilado | fonte-ok | invalido | ilegivel"""
    try:
        data = open(path, "rb").read()
    except OSError:
        return "ilegivel"
    if not data.startswith(PNG_SIG):
        return "invalido"
    if png_has_ninepatch(data):
        return "compilado"
    try:
        Image = _pil()
        im = Image.open(io.BytesIO(data)).convert("RGBA")
    except RuntimeError:
        return "fonte-ok" if data.startswith(PNG_SIG) else "invalido"
    except Exception:
        return "invalido"
    return "fonte-ok" if _border_ok(im) else "invalido"


def ensure_ninepatch(img_bytes):
    """
    Devolve bytes de um .9.png valido.
    Se ja estiver valido (fonte com borda ou compilado), devolve como veio.
    Senao, embrulha a imagem numa borda transparente de 1px (forma fonte).
    Retorna (bytes, converteu).
    """
    if png_has_ninepatch(img_bytes):
        return img_bytes, False
    Image = _pil()
    try:
        im = Image.open(io.BytesIO(img_bytes)).convert("RGBA")
    except Exception as e:
        raise RuntimeError("Nao consegui abrir a imagem: %s" % e)
    if _border_ok(im):
        return img_bytes, False
    w, h = im.size
    if w < 1 or h < 1:
        raise RuntimeError("Imagem vazia.")
    canvas = Image.new("RGBA", (w + 2, h + 2), (0, 0, 0, 0))
    canvas.paste(im, (1, 1))
    buf = io.BytesIO()
    canvas.save(buf, "PNG", optimize=True)
    return buf.getvalue(), True


def find_broken_ninepatch(project):
    """Lista os .9.png REALMENTE invalidos (borda incorreta)."""
    ruins = []
    for path in _iter_files(project, roots=["res"]):
        if not path.lower().endswith(".9.png"):
            continue
        if ninepatch_status(path) == "invalido":
            ruins.append(_rel(project, path))
    return ruins


def repair_ninepatches(project, log=None):
    """Conserta os .9.png invalidos adicionando a borda transparente de 1px."""
    ruins = find_broken_ninepatch(project)
    ok, falhas = [], []
    for rel in ruins:
        path = os.path.join(project, rel)
        try:
            novo, convertido = ensure_ninepatch(open(path, "rb").read())
            with open(path, "wb") as f:
                f.write(novo)
            ok.append(rel)
            if log:
                log("  consertado: %s" % rel)
        except Exception as e:
            falhas.append({"arquivo": rel, "erro": str(e)})
            if log:
                log("  [falhou] %s -> %s" % (rel, e))
    return {"consertados": ok, "falhas": falhas, "total": len(ruins)}


# ----------------------------------------------------------------------------
# Biblioteca de APKs
# ----------------------------------------------------------------------------
def list_apks():
    ensure_dirs()
    items = []
    if not os.path.isdir(APK_DIR):
        return items
    for f in sorted(os.listdir(APK_DIR), key=lambda x: x.lower()):
        if f.lower().endswith(".apk"):
            p = os.path.join(APK_DIR, f)
            try:
                size = os.path.getsize(p)
            except OSError:
                size = 0
            items.append({"name": f, "path": p, "size": size})
    return items


def apk_info(apk):
    info = {
        "file": os.path.basename(apk),
        "package": None, "versionName": None, "versionCode": None,
        "label": None, "icon": None, "minSdk": None, "targetSdk": None,
        "source": "aapt",
    }
    if not os.path.isfile(apk):
        return info
    if not which("aapt"):
        info["source"] = "indisponivel"
        return info
    rc, out = run(["aapt", "dump", "badging", apk])
    if rc != 0:
        info["source"] = "erro"
        return info
    m = re.search(r"package:\s*name='([^']*)'(?:\s*versionCode='([^']*)')?(?:\s*versionName='([^']*)')?", out)
    if m:
        info["package"], info["versionCode"], info["versionName"] = m.group(1), m.group(2), m.group(3)
    m = re.search(r"application-label(?:-[\w-]+)?:'([^']*)'", out)
    if m:
        info["label"] = m.group(1)
    icons = re.findall(r"application-icon-(\d+):'([^']*)'", out)
    if icons:
        icons.sort(key=lambda x: int(x[0]))
        info["icon"] = icons[-1][1]
    m = re.search(r"sdkVersion:'(\d+)'", out)
    if m:
        info["minSdk"] = m.group(1)
    m = re.search(r"targetSdkVersion:'(\d+)'", out)
    if m:
        info["targetSdk"] = m.group(1)
    return info


# ----------------------------------------------------------------------------
# Projeto (decompilacao)
# ----------------------------------------------------------------------------
def project_path(name):
    safe = re.sub(r"[^A-Za-z0-9._-]", "_", name)
    return os.path.join(PROJECTS_DIR, safe)


def decompile(apk, log=None, use_aapt2=False):
    ensure_dirs()
    base = os.path.splitext(os.path.basename(apk))[0]
    out = project_path(base)
    if os.path.isdir(out):
        shutil.rmtree(out, ignore_errors=True)
    cmd = ["apktool", "d", "-f", "-o", out, apk]
    if use_aapt2:
        cmd.insert(2, "--use-aapt2")
    rc, o = run(cmd, log=log)
    if rc != 0 or not os.path.isdir(out):
        erros = extrair_erros(o)
        raise RuntimeError("Falha ao decompilar o APK (codigo %s).%s" %
                           (rc, ("\n" + "\n".join(erros)) if erros else ""))
    write_meta(out, {"origem": os.path.basename(apk), "apk": apk, "nome": base})
    return out


def write_meta(project, data):
    try:
        with open(os.path.join(project, ".apkeditor.json"), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def read_meta(project):
    p = os.path.join(project, ".apkeditor.json")
    if os.path.isfile(p):
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def list_projects():
    ensure_dirs()
    out = []
    if not os.path.isdir(PROJECTS_DIR):
        return out
    for d in sorted(os.listdir(PROJECTS_DIR)):
        full = os.path.join(PROJECTS_DIR, d)
        if os.path.isdir(full):
            meta = read_meta(full)
            out.append({"nome": d, "path": full, "origem": meta.get("origem", ""),
                        "apk": meta.get("apk", "")})
    return out


# ----------------------------------------------------------------------------
# Manifest / apktool.yml
# ----------------------------------------------------------------------------
def manifest_path(project):
    return os.path.join(project, "AndroidManifest.xml")


def read_text(path):
    with open(path, "rb") as f:
        return f.read().decode("utf-8", errors="ignore")


def read_manifest(project):
    p = manifest_path(project)
    if os.path.isfile(p):
        return read_text(p)
    return ""


def project_info(project):
    man = read_manifest(project)
    info = {"package": None, "versionName": None, "versionCode": None,
            "label": None, "icon": None, "minSdk": None, "targetSdk": None,
            "nome": os.path.basename(project)}
    m = re.search(r'package="([^"]+)"', man)
    if m:
        info["package"] = m.group(1)
    m = re.search(r'android:versionName="([^"]*)"', man)
    if m:
        info["versionName"] = m.group(1)
    m = re.search(r'android:versionCode="([^"]*)"', man)
    if m:
        info["versionCode"] = m.group(1)
    m = re.search(r'<application[^>]*android:label="([^"]*)"', man, re.S)
    if m:
        info["label"] = m.group(1)
    m = re.search(r'<application[^>]*android:icon="([^"]*)"', man, re.S)
    if m:
        info["icon"] = m.group(1)

    yml = os.path.join(project, "apktool.yml")
    if os.path.isfile(yml):
        t = read_text(yml)
        m = re.search(r"minSdkVersion:\s*'?([0-9]+)", t)
        if m:
            info["minSdk"] = m.group(1)
        m = re.search(r"targetSdkVersion:\s*'?([0-9]+)", t)
        if m:
            info["targetSdk"] = m.group(1)
        if not info["versionCode"]:
            m = re.search(r"versionCode:\s*'?([^'\n\r]+)", t)
            if m:
                info["versionCode"] = m.group(1).strip()
        if not info["versionName"]:
            m = re.search(r"versionName:\s*'?([^'\n\r]+)", t)
            if m:
                info["versionName"] = m.group(1).strip()

    if info["label"] and info["label"].startswith("@string/"):
        key = info["label"].split("/", 1)[1]
        val = find_string(project, key)
        if val:
            info["label"] = val
    return info


def _iter_files(project, exts=None, roots=None):
    roots = roots or ["."]
    for root in roots:
        base = os.path.join(project, root)
        if not os.path.exists(base):
            continue
        if os.path.isfile(base):
            yield base
            continue
        for dp, dns, fns in os.walk(base):
            dns[:] = [d for d in dns if d not in ("dist", "build", ".git")]
            for fn in fns:
                full = os.path.join(dp, fn)
                if exts is None:
                    yield full
                    continue
                if os.path.splitext(fn)[1].lower() in exts:
                    yield full


def _rel(project, path):
    return os.path.relpath(path, project).replace("\\", "/")


def _safe_join(project, rel):
    rel = (rel or "").replace("\\", "/").lstrip("/")
    if not rel or ".." in rel.split("/"):
        raise ValueError("Caminho invalido.")
    full = os.path.abspath(os.path.join(project, rel))
    if not full.startswith(os.path.abspath(project) + os.sep):
        raise ValueError("Caminho fora do projeto.")
    return full


# ----------------------------------------------------------------------------
# Servidores / URLs
# ----------------------------------------------------------------------------
def _scan_roots(project):
    try:
        return [d for d in os.listdir(project)
                if d.startswith("smali") or d in ("res", "assets", "unknown", "lib", "kotlin", "META-INF")]
    except OSError:
        return ["."]


def _base_url(u):
    """Extrai o servidor (esquema + host + porta) de uma URL."""
    try:
        p = urlsplit(u)
        if p.scheme and p.netloc:
            return "%s://%s" % (p.scheme, p.netloc)
    except Exception:
        pass
    return u


def scan_urls(project, limit=5000):
    found = {}
    for path in _iter_files(project, roots=_scan_roots(project)):
        ext = os.path.splitext(path)[1].lower()
        if ext and ext not in TEXT_EXT:
            continue
        try:
            if os.path.getsize(path) > 12 * 1024 * 1024:
                continue
            data = open(path, "rb").read()
        except OSError:
            continue
        for m in URL_RE.finditer(data):
            u = m.group(0).decode("utf-8", errors="ignore").rstrip(".,;:\"')")
            if len(u) < 8 or len(u) > 300:
                continue
            e = found.setdefault(u, {"url": u, "count": 0, "files": set()})
            e["count"] += 1
            e["files"].add(_rel(project, path))
    out = [{"url": u, "count": e["count"], "files": sorted(e["files"])[:8],
            "fileCount": len(e["files"]), "servidor": _base_url(u)}
           for u, e in found.items()]
    out.sort(key=lambda x: (-x["count"], x["url"]))
    return out[:limit]


def scan_servers(project):
    """
    Agrupa as URLs por SERVIDOR (esquema + host + porta).
    E o que o usuario quer ver: clicar num servidor e trocar tudo dele.
    """
    grupos = {}
    for u in scan_urls(project):
        b = u["servidor"]
        g = grupos.setdefault(b, {"servidor": b, "count": 0, "urls": [], "files": set()})
        g["count"] += u["count"]
        g["urls"].append({"url": u["url"], "count": u["count"],
                           "fileCount": u["fileCount"], "files": u["files"]})
        g["files"].update(u["files"])
    out = []
    for b, g in grupos.items():
        g["urls"].sort(key=lambda x: (-x["count"], x["url"]))
        out.append({"servidor": b, "count": g["count"], "urls": g["urls"],
                    "urlCount": len(g["urls"]), "fileCount": len(g["files"]),
                    "files": sorted(g["files"])[:10]})
    out.sort(key=lambda x: (-x["count"], x["servidor"]))
    return out


def search_text(project, term, limit=200):
    if not term:
        return []
    tb = term.encode("utf-8", errors="ignore")
    res = []
    for path in _iter_files(project, roots=_scan_roots(project)):
        if os.path.splitext(path)[1].lower() not in TEXT_EXT:
            continue
        try:
            data = open(path, "rb").read()
        except OSError:
            continue
        c = data.count(tb)
        if c:
            res.append({"arquivo": _rel(project, path), "ocorrencias": c})
            if len(res) >= limit:
                break
    res.sort(key=lambda x: -x["ocorrencias"])
    return res


def replace_text(project, find, replace, exts=None, case_sensitive=True, log=None):
    if not find:
        return 0, 0
    exts = exts or TEXT_EXT
    fb = find.encode("utf-8", errors="ignore")
    rb = replace.encode("utf-8", errors="ignore")
    files_changed = total = 0
    for path in _iter_files(project, roots=_scan_roots(project)):
        if os.path.splitext(path)[1].lower() not in exts:
            continue
        try:
            data = open(path, "rb").read()
        except OSError:
            continue
        if case_sensitive:
            n = data.count(fb)
            if not n:
                continue
            new = data.replace(fb, rb)
        else:
            pat = re.compile(re.escape(fb), re.I)
            n = len(pat.findall(data))
            if not n:
                continue
            new = pat.sub(lambda _m: rb, data)
        try:
            with open(path, "wb") as f:
                f.write(new)
        except OSError:
            continue
        files_changed += 1
        total += n
        if log:
            log("  %s  (%d)" % (_rel(project, path), n))
    return files_changed, total


# ----------------------------------------------------------------------------
# Recursos visuais
# ----------------------------------------------------------------------------
def _categoria_imagem(nome, w, h):
    # ordem importa: icone antes de splash ("launch" esta dentro de "ic_launcher")
    if any(k in nome for k in ("ic_launcher", "app_icon", "ic_app", "icone",
                               "ic_launcher_round", "icon")):
        return "icone"
    if any(k in nome for k in ("logo", "marca", "brand", "logotipo")):
        return "logo"
    if any(k in nome for k in ("banner", "capa", "cover", "header", "topo",
                               "slide", "carousel", "destaque")):
        return "banner"
    if any(k in nome for k in ("splash", "intro", "loading", "abertura",
                               "launch_screen", "launchscreen", "start_screen")):
        return "splash"
    if any(k in nome for k in ("background", "fundo", "wallpaper", "bg_", "_bg",
                               "back_", "_back", "screen_bg", "main_bg")):
        return "fundo"
    if any(k in nome for k in ("button", "botao", "btn_")):
        return "botao"
    if w and h and w >= 400 and h >= 400:
        return "fundo"
    return "outra"


CATEGORIA_INFO = {
    "icone":  {"rotulo": "ÍCONE",   "dica": "ícone do app na tela inicial"},
    "logo":   {"rotulo": "LOGO",    "dica": "logotipo / marca"},
    "fundo":  {"rotulo": "FUNDO",   "dica": "imagem de fundo das telas"},
    "banner": {"rotulo": "BANNER",  "dica": "banner / capa / destaque"},
    "splash": {"rotulo": "SPLASH",  "dica": "tela de abertura"},
    "botao":  {"rotulo": "BOTÃO",   "dica": "imagem de botão"},
    "outra":  {"rotulo": "OUTRA",   "dica": "imagem comum"},
}


def list_images(project, max_dims=2500):
    """Todas as imagens do app, com dimensoes e categoria (para a galeria)."""
    try:
        from PIL import Image
    except Exception:
        Image = None
    out = []
    n = 0
    for path in _iter_files(project, exts=IMG_EXT, roots=["res", "assets"]):
        try:
            sz = os.path.getsize(path)
        except OSError:
            continue
        w = h = None
        if Image is not None and sz < 12 * 1024 * 1024 and n < max_dims:
            n += 1
            try:
                with Image.open(path) as im:
                    w, h = im.size
            except Exception:
                w = h = None
        base = os.path.basename(path)
        cat = _categoria_imagem(base.lower(), w, h)
        info = CATEGORIA_INFO.get(cat, CATEGORIA_INFO["outra"])
        out.append({"path": _rel(project, path), "name": base, "size": sz,
                    "ninepatch": path.lower().endswith(".9.png"),
                    "w": w, "h": h, "categoria": cat,
                    "rotulo": info["rotulo"], "dica": info["dica"]})
    ordem = {"icone": 0, "logo": 1, "fundo": 2, "banner": 3, "splash": 4, "botao": 5, "outra": 6}
    out.sort(key=lambda x: (ordem.get(x["categoria"], 9), x["path"]))
    return out


def contar_categorias(imagens):
    c = {}
    for i in imagens:
        c[i["categoria"]] = c.get(i["categoria"], 0) + 1
    return c


def list_fonts(project):
    out = []
    for path in _iter_files(project, exts=FONT_EXT, roots=["res", "assets"]):
        try:
            sz = os.path.getsize(path)
        except OSError:
            continue
        out.append({"path": _rel(project, path), "name": os.path.basename(path), "size": sz})
    out.sort(key=lambda x: x["path"])
    return out


def guess_launcher_icon(project):
    info = project_info(project)
    ref = (info.get("icon") or "").lstrip("@")
    cands = []
    for path in _iter_files(project, exts=IMG_EXT, roots=["res"]):
        base = os.path.basename(path)
        nome = os.path.splitext(base)[0].replace(".9", "")
        if ref and ref.split("/")[-1].split(".")[0] == nome:
            cands.append(_rel(project, path))
        elif any(k in base.lower() for k in ("ic_launcher", "app_icon", "ic_app", "icone", "logo")):
            cands.append(_rel(project, path))
    cands.sort(key=lambda p: (0 if "mipmap" in p else 1, p))
    return cands[:24]


def guess_backgrounds(project):
    """Fundo: por palavra-chave no nome OU por tamanho grande."""
    keys = ("background", "bg_", "_bg", "fundo", "wallpaper", "back_",
            "_back", "screen_bg", "main_bg")
    out = []
    for path in _iter_files(project, exts=IMG_EXT, roots=["res", "assets"]):
        if any(k in os.path.basename(path).lower() for k in keys):
            out.append(_rel(project, path))
    return out[:80]


def preview_path(project, rel):
    """Caminho absoluto seguro de um recurso para pre-visualizacao."""
    full = _safe_join(project, rel)
    if not os.path.isfile(full):
        raise FileNotFoundError(rel)
    if os.path.splitext(full)[1].lower() not in MIME:
        raise ValueError("Formato sem pre-visualizacao.")
    return full


def replace_resource(project, rel_path, data, log=None, convert_ninepatch=True):
    """Substitui um arquivo de recurso pelo conteudo enviado."""
    target = _safe_join(project, rel_path)
    avisos = []
    if target.lower().endswith(".9.png") and convert_ninepatch:
        data, convertido = ensure_ninepatch(data)
        if convertido:
            avisos.append("embrulhado com borda transparente (9-patch valido)")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "wb") as f:
        f.write(data)
    if log:
        log("  substituido: %s (%d bytes)%s" %
            (rel_path, len(data), ("  [" + "; ".join(avisos) + "]") if avisos else ""))
    return rel_path, avisos


def replace_resource_broad(project, kind, data, log=None):
    """
    Substitui TODAS as variantes (densidades) de um recurso mantendo o nome.
    Arquivos .9.png recebem a borda transparente de 1px automaticamente.
    """
    kind = (kind or "").lower()
    if kind.endswith(".png"):
        kind = kind[:-4]
    if kind.endswith(".9"):
        kind = kind[:-2]
    if len(kind) < 3:
        raise ValueError("Nome de recurso curto demais para substituicao em massa.")
    targets = [p for p in _iter_files(project, exts=IMG_EXT, roots=["res", "assets"])
               if kind in os.path.basename(p).lower()]
    if not targets:
        return 0, [], []
    # uma unica conversao reaproveitada por todas as variantes .9.png
    cache = {}
    files, avisos = [], []
    for t in targets:
        payload = data
        if t.lower().endswith(".9.png"):
            if "np" not in cache:
                cache["np"], conv = ensure_ninepatch(data)
                if conv:
                    avisos.append("borda transparente aplicada nas variantes .9.png")
            payload = cache["np"]
        try:
            with open(t, "wb") as f:
                f.write(payload)
            files.append(_rel(project, t))
            if log:
                log("  substituido: %s" % _rel(project, t))
        except OSError:
            pass
    return len(files), files, avisos


# ----------------------------------------------------------------------------
# strings.xml / nome do app
# ----------------------------------------------------------------------------
def find_string(project, key):
    paths = [p for p in _iter_files(project, exts={".xml"}, roots=["res"])
             if os.path.basename(p) == "strings.xml"]
    paths.sort(key=lambda p: (0 if os.path.dirname(p).replace("\\", "/").endswith("res/values") else 1, p))
    for path in paths:
        t = read_text(path)
        m = re.search(r'<string\s+name="%s"[^>]*>(.*?)</string>' % re.escape(key), t, re.S)
        if m:
            return m.group(1)
    return None


def list_app_strings(project, limit=800):
    p = os.path.join(project, "res", "values", "strings.xml")
    out = []
    if not os.path.isfile(p):
        return out
    t = read_text(p)
    for m in re.finditer(r'<string\s+name="([^"]+)"[^>]*>(.*?)</string>', t, re.S):
        out.append({"nome": m.group(1), "valor": m.group(2)})
        if len(out) >= limit:
            break
    return out


def set_app_name(project, novo, log=None):
    if not novo:
        return 0
    changed = 0
    for path in _iter_files(project, exts={".xml"}, roots=["res"]):
        if os.path.basename(path) != "strings.xml":
            continue
        t = read_text(path)
        new_t, n = re.subn(r'(<string\s+name="app_name"[^>]*>)(.*?)(</string>)',
                           lambda m: m.group(1) + novo + m.group(3), t, flags=re.S)
        if n:
            with open(path, "w", encoding="utf-8") as f:
                f.write(new_t)
            changed += n
            if log:
                log("  nome atualizado em %s" % _rel(project, path))
    mp = manifest_path(project)
    if os.path.isfile(mp):
        t = read_text(mp)
        new_t, n = re.subn(r'(android:label=")([^"@][^"]*)(")',
                           lambda m: m.group(1) + novo + m.group(3), t)
        if n:
            with open(mp, "w", encoding="utf-8") as f:
                f.write(new_t)
            changed += n
            if log:
                log("  label atualizado no AndroidManifest.xml")
    return changed


# ----------------------------------------------------------------------------
# Pacote / Versao
# ----------------------------------------------------------------------------
def rename_package(project, newpkg, log=None):
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$", newpkg or ""):
        raise ValueError("Pacote invalido. Use formato com.dominio.app")

    mp = manifest_path(project)
    man = read_text(mp)
    m = re.search(r'package="([^"]+)"', man)
    if not m:
        raise ValueError("Nao foi possivel encontrar o pacote no AndroidManifest.xml.")
    old = m.group(1)
    if old == newpkg:
        return {"antigo": old, "novo": newpkg, "smaliDirs": 0, "refs": 0, "recursos": 0}

    man2 = man.replace('package="%s"' % old, 'package="%s"' % newpkg)
    man2 = man2.replace('android:authorities="%s' % old, 'android:authorities="%s' % newpkg)
    with open(mp, "w", encoding="utf-8") as f:
        f.write(man2)
    if log:
        log("  AndroidManifest.xml: %s -> %s" % (old, newpkg))

    old_slash, new_slash = old.replace(".", "/"), newpkg.replace(".", "/")
    moved = 0
    for entry in os.listdir(project):
        if not entry.startswith("smali"):
            continue
        root = os.path.join(project, entry)
        src = os.path.join(root, *old.split("."))
        if os.path.isdir(src):
            dst = os.path.join(root, *newpkg.split("."))
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            if os.path.isdir(dst):
                shutil.rmtree(dst, ignore_errors=True)
            shutil.move(src, dst)
            moved += 1
            if log:
                log("  %s: %s -> %s" % (entry, old_slash, new_slash))
            parent = os.path.dirname(src)
            while parent.startswith(root) and parent != root:
                try:
                    os.rmdir(parent)
                except OSError:
                    break
                parent = os.path.dirname(parent)

    nref = 0
    for path in _iter_files(project, roots=[d for d in os.listdir(project) if d.startswith("smali")]):
        try:
            data = open(path, "rb").read()
        except OSError:
            continue
        if old_slash.encode() not in data:
            continue
        nref += data.count(old_slash.encode())
        with open(path, "wb") as f:
            f.write(data.replace(old_slash.encode(), new_slash.encode()))
    if log:
        log("  referencias smali atualizadas: %d" % nref)

    files_changed = 0
    for path in _iter_files(project, exts=TEXT_EXT, roots=["res", "assets", "unknown"]):
        try:
            data = open(path, "rb").read()
        except OSError:
            continue
        if old.encode() not in data:
            continue
        with open(path, "wb") as f:
            f.write(data.replace(old.encode(), newpkg.encode()))
        files_changed += 1
    if log:
        log("  recursos com referencia ao pacote: %d" % files_changed)

    return {"antigo": old, "novo": newpkg, "smaliDirs": moved,
            "refs": nref, "recursos": files_changed}


def set_version(project, version_name=None, version_code=None, log=None):
    mp = manifest_path(project)
    man = read_text(mp)
    if version_name:
        man = re.sub(r'android:versionName="[^"]*"',
                     'android:versionName="%s"' % version_name, man)
    if version_code:
        man = re.sub(r'android:versionCode="[^"]*"',
                     'android:versionCode="%s"' % version_code, man)
    with open(mp, "w", encoding="utf-8") as f:
        f.write(man)

    yml = os.path.join(project, "apktool.yml")
    if os.path.isfile(yml):
        t = read_text(yml)
        if version_name:
            t = re.sub(r"(\n\s*versionName:\s*).*", r"\g<1>'%s'" % version_name, t)
        if version_code:
            t = re.sub(r"(\n\s*versionCode:\s*).*", r"\g<1>'%s'" % version_code, t)
        with open(yml, "w", encoding="utf-8") as f:
            f.write(t)
    if log:
        log("  versao definida: %s (%s)" % (version_name, version_code))
    return True


# ----------------------------------------------------------------------------
# Cores
# ----------------------------------------------------------------------------
COLOR_STR_RE = re.compile(r"#(?:[0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})(?![0-9a-fA-F])")
COLOR_OK_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$")

# atributos de tema que mais mudam a cara do app
ATRIBUTOS_TEMA = (
    "colorPrimary", "colorPrimaryDark", "colorPrimaryVariant", "colorAccent",
    "colorSecondary", "colorSecondaryVariant", "colorOnPrimary", "colorOnSecondary",
    "colorBackground", "colorSurface", "colorError", "colorControlHighlight",
    "colorControlNormal", "colorControlActivated", "android:colorBackground",
    "android:textColorPrimary", "android:textColorSecondary", "android:windowBackground",
    "android:statusBarColor", "android:navigationBarColor", "android:textColor",
    "colorButtonNormal", "colorEdgeEffect", "colorOnBackground", "colorOnSurface",
)

# explicacao leiga de cada atributo (para o painel ficar didatico)
DESCRICAO_ATRIBUTO = {
    "colorPrimary": "Cor principal do app — normalmente a barra de título (topo)",
    "colorPrimaryDark": "Tom mais escuro da principal — barra de status do Android",
    "colorPrimaryVariant": "Variacao da cor principal",
    "colorAccent": "Cor de destaque — botões, seleções, interruptores, links",
    "colorSecondary": "Cor secundária do app",
    "colorSecondaryVariant": "Variacao da cor secundaria",
    "colorOnPrimary": "Cor do texto/ícone em cima da cor principal",
    "colorOnSecondary": "Cor do texto/ícone em cima da cor secundária",
    "colorBackground": "Cor de fundo das telas",
    "colorSurface": "Cor de superfície — cartões, menus, caixas",
    "colorError": "Cor de erro / alerta",
    "colorControlHighlight": "Cor do realce ao tocar (ripple)",
    "colorControlNormal": "Cor normal dos controles (checkbox, radio)",
    "colorControlActivated": "Cor dos controles ativados",
    "colorButtonNormal": "Cor padrão dos botões",
    "colorEdgeEffect": "Cor do efeito de borda ao rolar",
    "colorOnBackground": "Cor do texto em cima do fundo",
    "colorOnSurface": "Cor do texto em cima das superfícies",
    "android:colorBackground": "Cor de fundo das telas (janela)",
    "android:textColorPrimary": "Cor do texto principal",
    "android:textColorSecondary": "Cor do texto secundário",
    "android:windowBackground": "Fundo das telas (janela)",
    "android:statusBarColor": "Cor da barra de status (topo do celular)",
    "android:navigationBarColor": "Cor da barra de navegação (embaixo)",
    "android:textColor": "Cor geral do texto",
}


def normalizar_cor(v):
    v = (v or "").strip()
    if not v.startswith("#"):
        v = "#" + v
    if not COLOR_OK_RE.match(v):
        raise ValueError("Cor invalida. Use #RGB, #RRGGBB ou #AARRGGBB")
    return v.upper()


def buscar_enderecos(project, termo):
    """
    Busca um endereco/servidor no projeto (estilo APK Editor).
    Devolve o que casou, agrupado por servidor e por endereco, com contagens.
    """
    termo = (termo or "").strip()
    if len(termo) < 3:
        return {"termo": termo, "servidores": [], "urls": [],
                "total": 0, "arquivos": 0, "erro": "Digite pelo menos 3 caracteres."}
    tl = termo.lower()
    casadas = [u for u in scan_urls(project) if tl in u["url"].lower()]

    grupos = {}
    for u in casadas:
        b = u["servidor"]
        g = grupos.setdefault(b, {"servidor": b, "count": 0, "urls": [], "files": set()})
        g["count"] += u["count"]
        g["urls"].append({"url": u["url"], "count": u["count"],
                           "fileCount": u["fileCount"], "files": u["files"]})
        g["files"].update(u["files"])
    servidores = []
    for b, g in grupos.items():
        g["urls"].sort(key=lambda x: (-x["count"], x["url"]))
        servidores.append({"servidor": b, "count": g["count"], "urls": g["urls"],
                           "urlCount": len(g["urls"]), "fileCount": len(g["files"]),
                           "files": sorted(g["files"])[:10]})
    servidores.sort(key=lambda x: (-x["count"], x["servidor"]))

    # busca textual (pega o que nao aparece como URL completa, ex: em smali)
    ocorrencias = search_text(project, termo)
    return {"termo": termo, "servidores": servidores, "urls": casadas,
            "total": sum(u["count"] for u in casadas),
            "arquivos": len({f for u in casadas for f in u["files"]}),
            "ocorrencias": ocorrencias[:40]}


def list_colors(project, max_valores=400):
    """
    Lista as cores do app:
      nomeadas -> <color name="..."> dos values/colors.xml (com contagem de usos)
      valores  -> todos os hex crus usados nos XMLs de res/
      temas    -> atributos de tema (colorPrimary, colorAccent...) e o valor atual
    """
    nomeadas, valores, temas = [], {}, []
    for path in _iter_files(project, exts={".xml"}, roots=["res"]):
        rel = _rel(project, path)
        base = os.path.basename(path)
        t = read_text(path)

        # <color name="x">#ff0000</color>
        for m in re.finditer(r'<color\s+name="([^"]+)"[^>]*>\s*([^<\s]+)\s*</color>', t):
            nome, val = m.group(1), m.group(2)
            nomeadas.append({"nome": nome, "valor": val, "arquivo": rel,
                             "usos": 0, "valido": bool(COLOR_OK_RE.match(val or ""))})

        # atributos de tema em styles.xml
        if base in ("styles.xml", "themes.xml"):
            for m in re.finditer(r'<item\s+name="([^"]+)"[^>]*>\s*([^<\s]+)\s*</item>', t):
                chave, val = m.group(1), m.group(2)
                if chave in ATRIBUTOS_TEMA:
                    temas.append({"chave": chave, "valor": val, "arquivo": rel,
                                  "descricao": DESCRICAO_ATRIBUTO.get(chave, "")})

        # hex crus
        for m in COLOR_STR_RE.finditer(t):
            v = m.group(0).upper()
            e = valores.setdefault(v, {"valor": v, "count": 0, "files": set()})
            e["count"] += 1
            e["files"].add(rel)

    # quantas vezes cada cor nomeada e referenciada como @color/nome
    for c in nomeadas:
        alvo = "@color/%s" % c["nome"]
        n = 0
        for path in _iter_files(project, exts={".xml"}, roots=["res"]):
            n += read_text(path).count(alvo)
        c["usos"] = n

    lista = [{"valor": v, "count": e["count"], "fileCount": len(e["files"]),
              "files": sorted(e["files"])[:6]} for v, e in valores.items()]
    lista.sort(key=lambda x: (-x["count"], x["valor"]))
    nomeadas.sort(key=lambda x: (-x["usos"], x["nome"]))
    return {"nomeadas": nomeadas, "valores": lista[:max_valores], "temas": temas}


def definir_cor_nomeada(project, nome, nova, global_=True, log=None):
    """Troca o valor de <color name="..."> e, opcionalmente, o hex antigo em todo o res/."""
    nova = normalizar_cor(nova)
    alterados, antigos = 0, set()
    for path in _iter_files(project, exts={".xml"}, roots=["res"]):
        t = read_text(path)
        def _sub(m):
            if m.group(1) == nome:
                antigos.add(m.group(2).upper())
                return m.group(0).replace(m.group(2), nova)
            return m.group(0)
        novo_t, n = re.subn(r'<color\s+name="([^"]+)"[^>]*>\s*([^<\s]+)\s*</color>',
                            _sub, t)
        if novo_t != t:
            with open(path, "w", encoding="utf-8") as f:
                f.write(novo_t)
            alterados += n
            if log:
                log("  %s -> %s em %s" % (nome, nova, _rel(project, path)))
    if not alterados:
        raise ValueError('Nao encontrei a cor "%s" no projeto.' % nome)

    trocados = 0
    if global_:
        for velho in antigos:
            if velho == nova:
                continue
            _, o = replace_text(project, velho, nova, exts={".xml"})
            trocados += o
        if log and trocados:
            log("  %d ocorrencia(s) do valor antigo tambem trocadas" % trocados)
    return {"nome": nome, "nova": nova, "antigos": sorted(antigos),
            "declaracoes": alterados, "ocorrencias": trocados}


def substituir_cor(project, antiga, nova, log=None):
    """Troca um valor de cor por outro em todos os XMLs de res/."""
    antiga = normalizar_cor(antiga)
    nova = normalizar_cor(nova)
    if antiga == nova:
        return {"antiga": antiga, "nova": nova, "arquivos": 0, "ocorrencias": 0}
    f, o = replace_text(project, antiga, nova, exts={".xml"})
    # tambem cobre a forma minuscula
    f2, o2 = replace_text(project, antiga.lower(), nova, exts={".xml"})
    if log:
        log("  %s -> %s : %d ocorrencia(s) em %d arquivo(s)"
            % (antiga, nova, o + o2, f + f2))
    return {"antiga": antiga, "nova": nova,
            "arquivos": f + f2, "ocorrencias": o + o2}


# ----------------------------------------------------------------------------
# Gradientes (res/drawable/*.xml com <gradient>)
# ----------------------------------------------------------------------------
GRAD_RE = re.compile(r"<gradient\b[^>]*/?>", re.I)


def _grad_attr(tag, nome):
    m = re.search(r'android:%s="([^"]+)"' % nome, tag)
    return m.group(1) if m else None


def list_gradients(project):
    """Lista todos os gradientes declarados nos drawables."""
    out = []
    for path in _iter_files(project, exts={".xml"}, roots=["res"]):
        rel = _rel(project, path)
        t = read_text(path)
        for i, m in enumerate(GRAD_RE.finditer(t)):
            tag = m.group(0)
            out.append({
                "arquivo": rel, "index": i,
                "startColor": _grad_attr(tag, "startColor"),
                "endColor": _grad_attr(tag, "endColor"),
                "centerColor": _grad_attr(tag, "centerColor"),
                "angle": _grad_attr(tag, "angle"),
                "type": _grad_attr(tag, "type") or "linear",
            })
    return out


def _set_tag_attr(tag, attr, val):
    pat = re.compile(r'android:%s="[^"]*"' % re.escape(attr))
    if pat.search(tag):
        return pat.sub(lambda _m: 'android:%s="%s"' % (attr, val), tag)
    if tag.endswith("/>"):
        return tag[:-2] + ' android:%s="%s"/>' % (attr, val)
    if tag.endswith(">"):
        return tag[:-1] + ' android:%s="%s">' % (attr, val)
    return tag


def set_gradient(project, rel, index=0, start=None, end=None, center=None,
                 angle=None, tipo=None, log=None):
    """Troca as cores/angulo de um gradiente existente."""
    p = _safe_join(project, rel)
    if not os.path.isfile(p):
        raise FileNotFoundError(rel)
    t = read_text(p)
    marcas = list(GRAD_RE.finditer(t))
    index = int(index or 0)
    if index < 0 or index >= len(marcas):
        raise ValueError("Gradiente nao encontrado nesse arquivo.")
    m = marcas[index]
    tag = m.group(0)
    if start:
        tag = _set_tag_attr(tag, "startColor", normalizar_cor(start))
    if end:
        tag = _set_tag_attr(tag, "endColor", normalizar_cor(end))
    if center:
        tag = _set_tag_attr(tag, "centerColor", normalizar_cor(center))
    if angle not in (None, ""):
        tag = _set_tag_attr(tag, "angle", str(int(angle)))
    if tipo in ("linear", "radial", "sweep"):
        tag = _set_tag_attr(tag, "type", tipo)
    with open(p, "w", encoding="utf-8") as f:
        f.write(t[:m.start()] + tag + t[m.end():])
    if log:
        log("  %s (gradiente %d): %s" % (rel, index, tag))
    return {"arquivo": rel, "index": index, "tag": tag,
            "startColor": _grad_attr(tag, "startColor"),
            "endColor": _grad_attr(tag, "endColor"),
            "angle": _grad_attr(tag, "angle")}


# ----------------------------------------------------------------------------
# Splash / intro
# ----------------------------------------------------------------------------
def guess_splash(project):
    keys = ("splash", "intro", "loading", "abertura", "start", "launch")
    imgs, xmls = [], []
    for path in _iter_files(project, exts=IMG_EXT, roots=["res", "assets"]):
        if any(k in os.path.basename(path).lower() for k in keys):
            imgs.append(_rel(project, path))
    for path in _iter_files(project, exts={".xml"}, roots=["res"]):
        if any(k in os.path.basename(path).lower() for k in keys):
            xmls.append(_rel(project, path))
    return {"imagens": imgs[:40], "layouts": xmls[:40]}


def read_layout(project, rel):
    p = _safe_join(project, rel)
    if not os.path.isfile(p):
        raise FileNotFoundError(rel)
    return read_text(p)


def write_layout(project, rel, content, log=None):
    p = _safe_join(project, rel)
    with open(p, "w", encoding="utf-8") as f:
        f.write(content)
    if log:
        log("  layout salvo: %s" % rel)
    return rel


# ----------------------------------------------------------------------------
# Assinatura e build
# ----------------------------------------------------------------------------
def ensure_keystore(log=None):
    if os.path.isfile(KEYSTORE):
        return KEYSTORE
    os.makedirs(KEYSTORE_DIR, exist_ok=True)
    rc, _ = run([
        "keytool", "-genkeypair", "-v", "-keystore", KEYSTORE,
        "-alias", KS_ALIAS, "-keyalg", "RSA", "-keysize", "2048",
        "-validity", "10000", "-storepass", KS_PASS, "-keypass", KS_PASS,
        "-dname", "CN=APK Editor Pro, O=Joao, C=BR",
    ], log=log)
    if rc != 0 or not os.path.isfile(KEYSTORE):
        raise RuntimeError("Falha ao criar o keystore de assinatura.")
    return KEYSTORE


def clean_build(project, log=None):
    b = os.path.join(project, "build")
    if os.path.isdir(b):
        shutil.rmtree(b, ignore_errors=True)
        if log:
            log("  build/ anterior removido")


def _build_cmd(project, out, variante):
    cmd = ["apktool", "b", project, "-o", out]
    if variante == "aapt2":
        cmd.append("--use-aapt2")
    elif variante == "nocranch":
        cmd.append("--no-crunch")
    elif variante == "aapt1":
        a = which("aapt")
        if a:
            cmd += ["--aapt", a]
    return cmd


def assinar_apk(aligned, final, log=None):
    """Assina usando o melhor assinador disponivel. Devolve o nome do usado."""
    modo = assinador_disponivel()

    if modo == "apksigner":
        rc, _ = run([
            "apksigner", "sign",
            "--ks", KEYSTORE,
            "--ks-pass", "pass:" + KS_PASS,
            "--key-pass", "pass:" + KS_PASS,
            "--ks-key-alias", KS_ALIAS,
            "--v1-signing-enabled", "true",
            "--v2-signing-enabled", "true",
            "--out", final, aligned,
        ], log=log)
        if rc == 0 and os.path.isfile(final):
            return "apksigner"
        if log:
            log("  [aviso] apksigner falhou; tentando outra forma...")

    if modo in ("apksigner", "uber") and os.path.isfile(UBER_JAR):
        if log:
            log("  usando o assinador portatil (uber-apk-signer)...")
        tmp = tempfile.mkdtemp(prefix="apksign_")
        rc, _ = run(["java", "-jar", UBER_JAR, "--apks", aligned,
                     "--ks", KEYSTORE, "--ksAlias", KS_ALIAS,
                     "--ksPass", KS_PASS, "--ksKeyPass", KS_PASS,
                     "--out", tmp], log=log)
        gerados = []
        if os.path.isdir(tmp):
            gerados = [os.path.join(tmp, f) for f in sorted(os.listdir(tmp))
                       if f.lower().endswith(".apk")]
        if gerados:
            shutil.copy(gerados[0], final)
            shutil.rmtree(tmp, ignore_errors=True)
            return "uber-apk-signer"
        shutil.rmtree(tmp, ignore_errors=True)

    if which("jarsigner"):
        if log:
            log("  [aviso] usando jarsigner (assinatura v1) — pode nao instalar no Android 11+")
        rc, _ = run(["jarsigner", "-keystore", KEYSTORE,
                     "-storepass", KS_PASS, "-keypass", KS_PASS,
                     "-sigalg", "SHA256withRSA", "-digestalg", "SHA-256",
                     aligned, KS_ALIAS], log=log)
        if rc == 0:
            shutil.copy(aligned, final)
            return "jarsigner (v1)"

    raise RuntimeError(
        "Nenhum assinador disponivel.\n"
        "Toque no botao \"Instalar ferramentas\" no topo do painel,\n"
        "ou rode no Termux:  pkg install x11-repo && pkg install apksigner")


def verificar_assinatura(apk):
    if which("apksigner"):
        rc, _ = run(["apksigner", "verify", "--print-certs", apk], log=None)
        return rc == 0
    try:
        import zipfile
        with zipfile.ZipFile(apk) as z:
            nomes = z.namelist()
        return any(n.startswith("META-INF/") and
                   n.upper().endswith((".RSA", ".DSA", ".EC", ".SF"))
                   for n in nomes)
    except Exception:
        return False


def build(project, out_name=None, log=None, modo="auto", limpar=True, auto_nomes=True):
    """
    Recompila + alinha + assina.
    modo: auto | padrao | aapt2 | aapt1 | nocranch
    'auto' tenta em sequencia ate uma funcionar.
    auto_nomes: corrige sozinho recursos com nome invalido ($avd_... etc).
    """
    ensure_dirs()
    ensure_keystore(log)

    # nomes invalidos quebram o aapt2 sempre -> corrige antes de tentar
    if auto_nomes:
        inv = achar_nomes_invalidos(project)
        if inv:
            if log:
                log("→ %d recurso(s) com nome invalido (ex: $avd_...) — corrigindo..." % len(inv))
            r = corrigir_nomes_invalidos(project, log=log)
            if log:
                log("  %d renomeado(s), public.xml e referencias atualizados" % r["total"])
                log("")

    nome = out_name or (os.path.basename(project) + "-editado")
    if not nome.lower().endswith(".apk"):
        nome += ".apk"

    dist = os.path.join(project, "dist")
    os.makedirs(dist, exist_ok=True)
    unsigned = os.path.join(dist, "unsigned.apk")
    aligned = os.path.join(dist, "aligned.apk")

    if modo == "auto":
        variantes = ["padrao", "nocranch", "aapt2"]
    else:
        variantes = [modo]

    ultimo_erro, usada, saida = None, None, ""
    for v in variantes:
        for f in (unsigned, aligned):
            if os.path.exists(f):
                try:
                    os.remove(f)
                except OSError:
                    pass
        if limpar:
            clean_build(project, log)
        if log:
            log("")
            log("── tentativa: modo %s ────────────────────────" % v)
        rc, o = run(_build_cmd(project, unsigned, v), log=log)
        if rc == 0 and os.path.isfile(unsigned):
            usada, saida = v, o
            break
        erros = extrair_erros(o)
        ultimo_erro = erros or [o.strip()[-400:]]
        if log:
            log("  [falhou no modo %s]" % v)
        if v != variantes[-1] and log:
            log("  tentando o proximo modo...")

    if not usada:
        # diagnostico util antes de desistir
        ruins = find_broken_ninepatch(project)
        nomes = achar_nomes_invalidos(project)
        dicas = []
        if ruins:
            dicas.append(">> %d arquivo(s) .9.png INVALIDO(S):\n   %s\n   Use o botao 'Verificar recursos' e conserte."
                         % (len(ruins), "\n   ".join(ruins[:8])))
        if nomes:
            dicas.append(">> %d recurso(s) com NOME INVALIDO (ex: comecando com $):\n   %s\n   Use o botao 'Corrigir nomes invalidos'."
                         % (len(nomes), "\n   ".join(n["arquivo"] for n in nomes[:8])))
        dica = ("\n\n" + "\n\n".join(dicas)) if dicas else ""
        raise RuntimeError("Falha ao recompilar (apktool b).\n" +
                           "\n".join(ultimo_erro) + dica)

    if log:
        log("")
        log("✔ recompilado com sucesso (modo %s)" % usada)

    rc, _ = run(["zipalign", "-f", "4", unsigned, aligned], log=log)
    if rc != 0 or not os.path.isfile(aligned):
        if log:
            log("[aviso] zipalign falhou; seguindo com o APK nao alinhado.")
        aligned = unsigned

    final = os.path.join(OUTPUT_DIR, nome)
    if os.path.exists(final):
        try:
            os.remove(final)
        except OSError:
            pass
    usado = assinar_apk(aligned, final, log=log)
    if not os.path.isfile(final):
        raise RuntimeError("Falha ao assinar o APK. Veja o log acima.")

    ok = verificar_assinatura(final)
    if log:
        log("")
        log("APK assinado e salvo em:")
        log("  " + final)
        log("Assinador: %s" % usado)
        log("Verificacao da assinatura: " + ("OK" if ok else "nao confirmada"))
    return {"path": final, "name": nome, "size": os.path.getsize(final),
            "verified": ok, "modo": usada, "assinador": usado}


_ERRO_RE = re.compile(r"(?i)(^|[\s:])error(:|\s|$)|^\s*ERROR")


def _tem_erro(txt):
    """Deteccao estrita de erro do aapt2 (evita pegar 'warning')."""
    return any(_ERRO_RE.search(l) for l in (txt or "").splitlines())


# ----------------------------------------------------------------------------
# Nomes de recurso invalidos para o aapt2
#
# O aapt2 recusa nomes que nao casam com  ^[A-Za-z_][A-Za-z0-9_.]*$  .
# Caso classico: APKs do Android Studio trazem recursos internos de
# Animated Vector Drawable chamados  $avd_hide_password__0  /  $avd_show_password__N
# (o prefixo $ vem dos "inline resources" do AGP). O aapt2 aborta com:
#   error: resource 'drawable/$avd_hide_password__0' has invalid entry name
#   error: res/values/public.xml: error: file failed to compile.
# Solucao: renomear o arquivo e atualizar public.xml + todas as referencias.
# ----------------------------------------------------------------------------
NOME_OK_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*$")


def nome_recurso_valido(nome):
    return bool(nome) and bool(NOME_OK_RE.match(nome))


def _sanitizar_nome(nome):
    n = nome.lstrip("$")
    n = re.sub(r"[^A-Za-z0-9_.]", "_", n)
    n = n.strip(".")
    if not n or not re.match(r"^[A-Za-z_]", n):
        n = "_" + n
    return n


def _split_res_name(base):
    """Separa nome e extensao tratando o caso .9.png."""
    if base.lower().endswith(".9.png"):
        return base[:-6], ".9.png"
    nome, ext = os.path.splitext(base)
    return nome, ext


def achar_nomes_invalidos(project):
    ruins = []
    for path in _iter_files(project, roots=["res"]):
        nome, _ = _split_res_name(os.path.basename(path))
        if not nome_recurso_valido(nome):
            ruins.append({"arquivo": _rel(project, path), "nome": nome})
    return ruins


def corrigir_nomes_invalidos(project, log=None):
    """Renomeia recursos com nome invalido e atualiza public.xml + referencias."""
    res = os.path.join(project, "res")
    if not os.path.isdir(res):
        return {"renomeados": [], "total": 0}

    alvos = []
    for path in _iter_files(project, roots=["res"]):
        nome, ext = _split_res_name(os.path.basename(path))
        if not nome_recurso_valido(nome):
            alvos.append((path, nome, ext))

    renomeados = []
    for path, nome, ext in alvos:
        novo = _sanitizar_nome(nome)
        cand, i = novo, 1
        while os.path.exists(os.path.join(os.path.dirname(path), cand + ext)):
            i += 1
            cand = "%s_%d" % (novo, i)
        destino = os.path.join(os.path.dirname(path), cand + ext)
        try:
            os.rename(path, destino)
        except OSError as e:
            if log:
                log("  [falhou] %s -> %s" % (nome, e))
            continue
        renomeados.append({"de": nome, "para": cand, "arquivo": _rel(project, path)})
        if log:
            log("  %s  ->  %s" % (nome, cand))

    # atualiza referencias (public.xml, layouts, drawables, styles...)
    for r in renomeados:
        replace_text(project, r["de"], r["para"], exts={".xml"}, case_sensitive=True)

    # entradas de public.xml que nao tem arquivo correspondente
    pub = os.path.join(res, "values", "public.xml")
    if os.path.isfile(pub):
        t = read_text(pub)

        def _fix(m):
            nome = m.group(2)
            if nome_recurso_valido(nome):
                return m.group(0)
            return m.group(1) + _sanitizar_nome(nome) + m.group(3)

        novo_t = re.sub(r'(name=")([^"]+)(")', _fix, t)
        if novo_t != t:
            with open(pub, "w", encoding="utf-8") as f:
                f.write(novo_t)
            if log:
                log("  res/values/public.xml normalizado")
    return {"renomeados": renomeados, "total": len(renomeados)}


def verificar_recursos(project, log=None):
    """
    Checagem local (sem aapt2): acha arquivos que comprovadamente quebram o build.
    Retorna {'problemas': [...], 'avisos': [...], 'ninepatch_ruins': [...]}
    """
    problemas, avisos = [], []
    res = os.path.join(project, "res")
    if not os.path.isdir(res):
        return {"problemas": [], "avisos": [], "ninepatch_ruins": []}
    nome_re = re.compile(r"^[a-z0-9][a-z0-9_.]*$")
    for path in _iter_files(project, roots=["res"]):
        rel = _rel(project, path)
        base = os.path.basename(path)
        try:
            size = os.path.getsize(path)
        except OSError:
            continue
        if size == 0:
            problemas.append({"arquivo": rel, "tipo": "vazio",
                              "detalhe": "arquivo vazio (0 bytes)"})
            continue
        nome_base, _ext = _split_res_name(base)
        if not nome_recurso_valido(nome_base):
            problemas.append({"arquivo": rel, "tipo": "nome",
                              "detalhe": "nome de recurso invalido para o aapt2 "
                                         "(nao pode comecar com $ nem ter caracteres especiais)"})
        elif not nome_re.match(nome_base):
            avisos.append({"arquivo": rel, "tipo": "nome",
                           "detalhe": "nome fora do padrao (minusculas, numeros, _ e .)"})
        ext = os.path.splitext(base)[1].lower()
        if ext not in IMG_EXT:
            continue
        try:
            head = open(path, "rb").read(16)
        except OSError:
            continue
        low = base.lower()
        if low.endswith(".9.png") or ext == ".png":
            if not head.startswith(PNG_SIG):
                problemas.append({"arquivo": rel, "tipo": "imagem",
                                  "detalhe": "extensao .png mas o conteudo nao e PNG"})
            elif low.endswith(".9.png") and ninepatch_status(path) == "invalido":
                problemas.append({"arquivo": rel, "tipo": "9patch",
                                  "detalhe": "9-patch invalido: a borda de 1px precisa ser transparente ou preta"})
        elif ext in (".jpg", ".jpeg") and not head.startswith(b"\xff\xd8"):
            problemas.append({"arquivo": rel, "tipo": "imagem",
                              "detalhe": "extensao .jpg mas o conteudo nao e JPEG"})
        elif ext == ".webp" and not (head[:4] == b"RIFF" and head[8:12] == b"WEBP"):
            problemas.append({"arquivo": rel, "tipo": "imagem",
                              "detalhe": "extensao .webp mas o conteudo nao e WebP"})
        elif ext == ".gif" and not head.startswith(b"GIF8"):
            problemas.append({"arquivo": rel, "tipo": "imagem",
                              "detalhe": "extensao .gif mas o conteudo nao e GIF"})

    # entradas de public.xml com nome invalido (quebram o aapt2)
    pub = os.path.join(res, "values", "public.xml")
    if os.path.isfile(pub):
        t = read_text(pub)
        invalidos = sorted({m.group(1) for m in re.finditer(r'name="([^"]+)"', t)
                            if not nome_recurso_valido(m.group(1))})
        if invalidos:
            problemas.append({"arquivo": "res/values/public.xml", "tipo": "nome",
                              "detalhe": "%d entrada(s) com nome invalido, ex: %s" %
                                         (len(invalidos), ", ".join(invalidos[:4]))})
    if log:
        log("  %d problema(s), %d aviso(s)" % (len(problemas), len(avisos)))
    return {"problemas": problemas, "avisos": avisos,
            "ninepatch_ruins": find_broken_ninepatch(project)}


def diagnosticar_recursos(project, log=None, max_arquivos=2500):
    """
    Roda o aapt2 e, se falhar, isola o arquivo exato:
      1) compila res/ inteiro
      2) se falhar, compila cada subpasta de res/
      3) na subpasta que falha, compila arquivo por arquivo
    """
    res = os.path.join(project, "res")
    out = {"ok": True, "erros": [], "arquivos": [], "dirs": [],
           "local": verificar_recursos(project)}
    if not os.path.isdir(res):
        return {"ok": False, "erros": ["pasta res/ nao encontrada"],
                "arquivos": [], "dirs": [], "local": out["local"]}
    if not which("aapt2"):
        return {"ok": False, "erros": ["aapt2 nao encontrado no sistema"],
                "arquivos": [], "dirs": [], "local": out["local"]}

    tmp = os.path.join(project, "build", "diag")
    os.makedirs(tmp, exist_ok=True)
    alvo = os.path.join(tmp, "all.zip")

    if log:
        log("$ aapt2 compile --dir res")
    rc, o = run(["aapt2", "compile", "--dir", res, "-o", alvo], log=None)
    if rc == 0 and not _tem_erro(o):
        if log:
            log("  OK: o aapt2 compilou res/ sem erro.")
        return out

    out["ok"] = False
    out["erros"] = extrair_erros(o, 30)
    if log:
        log("  o aapt2 recusou res/ — isolando o arquivo...")

    for sub in sorted(os.listdir(res)):
        d = os.path.join(res, sub)
        if not os.path.isdir(d):
            continue
        rc2, o2 = run(["aapt2", "compile", "--dir", d, "-o", os.path.join(tmp, "d.zip")])
        if rc2 == 0 and not _tem_erro(o2):
            continue
        out["dirs"].append({"dir": sub, "erros": extrair_erros(o2, 4)})
        if log:
            log("  ✖ pasta suspeita: res/%s" % sub)
        n = 0
        for f in sorted(os.listdir(d)):
            fp = os.path.join(d, f)
            if not os.path.isfile(fp):
                continue
            n += 1
            if n > max_arquivos:
                break
            rc3, o3 = run(["aapt2", "compile", fp, "-o", os.path.join(tmp, "f.zip")])
            if rc3 != 0 or _tem_erro(o3):
                rel = _rel(project, fp)
                out["arquivos"].append({"arquivo": rel, "erros": extrair_erros(o3, 4)})
                if log:
                    log("  ✖ ARQUIVO RUIM: %s" % rel)
    return out


def diagnostico(project, log=None):
    """Compatibilidade: diagnostico completo com isolamento de arquivo."""
    return diagnosticar_recursos(project, log=log)


# ----------------------------------------------------------------------------
# Executor de tarefas em background (com log ao vivo)
# ----------------------------------------------------------------------------
class JobManager:
    def __init__(self):
        self.jobs = {}
        self.lock = threading.Lock()

    def start(self, kind, fn):
        import uuid
        jid = uuid.uuid4().hex[:12]
        job = {"id": jid, "kind": kind, "status": "rodando", "log": [],
               "result": None, "error": None, "started": time.time()}
        with self.lock:
            self.jobs[jid] = job
            if len(self.jobs) > 40:
                for k in sorted(self.jobs, key=lambda k: self.jobs[k]["started"])[:-20]:
                    self.jobs.pop(k, None)

        def log(line):
            with self.lock:
                job["log"].append(str(line))
                if len(job["log"]) > 6000:
                    del job["log"][:1500]

        def worker():
            try:
                res = fn(log)
                with self.lock:
                    job["result"] = res
                    job["status"] = "concluido"
            except Exception as e:
                with self.lock:
                    job["error"] = str(e)
                    job["status"] = "erro"
                    job["log"].append("[ERRO] " + str(e))

        threading.Thread(target=worker, daemon=True).start()
        return jid

    def get(self, jid, since=0):
        with self.lock:
            job = self.jobs.get(jid)
            if not job:
                return None
            return {"id": job["id"], "kind": job["kind"], "status": job["status"],
                    "log": job["log"][since:], "next": len(job["log"]),
                    "result": job["result"], "error": job["error"]}


JOBS = JobManager()
